"""Separate exported RF time from legacy follow/scheduling time. No hardware I/O."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
R=Path(__file__).resolve().parent
base=R/'source-rxdiag128';src=R/'source-rxtiming129';parent='75c382000308d7d78f5c9302ea274b1553981552'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip()==parent
assert not src.exists()
subprocess.run(['git','worktree','add','-b','candidate/rx-hardware-timestamps129',str(src),parent],cwd=R/'source',check=True,capture_output=True)
for sub in ['whad-lib','whad-lib/nanopb']:
 subprocess.run(['git','clone','--shared',str(base/sub),str(src/sub)],check=True,capture_output=True)
shutil.copytree(base/'build',src/'build')
header=src/'src/radio.h';s=header.read_text();s=s.replace('char *radioRxSnapshotStats();','''char *radioRxSnapshotStats();
// Valid only for the currently executing completed-RX callback and its legacy
// stamp. The legacy clock remains exclusively owned by connection scheduling.
bool radioCurrentRxHardwareStart(uint32_t legacyStamp, uint32_t *start);''');header.write_text(s)
radio=src/'src/radio.cpp';s=radio.read_text();s=s.replace('char rxStatsText[420];','''uint32_t rxExportLegacy=0,rxExportStart=0;
bool rxExportActive=false;
char rxStatsText[420];''')
needle='// Global instance of Radio'
s=s.replace(needle,'''bool radioCurrentRxHardwareStart(uint32_t legacyStamp, uint32_t *start) {
    if (!start || !rxExportActive || legacyStamp!=rxExportLegacy) return false;
    *start=rxExportStart;
    return true;
}
'''+needle,1)
needle='\t\t\t\t\t\tcontroller->onReceiveWide(Radio::instance->currentTimestamp,bufferSize,buffer,crcValue, rssi);'
assert s.count(needle)==1
s=s.replace(needle,'''                        // END is latched by PPI before the interrupt can be delayed.
                        // bufferSize already includes the PDU header and encrypted
                        // MIC. Physical preamble is 1B on1M,2B on2M; AA is4B,
                        // configured CRC is3B. Do not reuse the old arbitrary100us
                        // correction or change the controller's internal clock.
                        rxExportActive=rxEndCaptureEnabled &&
                            (p==BLE_1MBITS || p==BLE_2MBITS) &&
                            Radio::instance->getCrc()==HARDWARE_CRC &&
                            Radio::instance->getCrcSize()==3 &&
                            Radio::instance->getPreamble().size==4;
                        if (rxExportActive) {
                            const uint32_t octets=bufferSize+4U+3U+(p==BLE_2MBITS ? 2U : 1U);
                            rxExportLegacy=Radio::instance->currentTimestamp;
                            rxExportStart=hardwareEnd-octets*(p==BLE_2MBITS ? 4U : 8U);
                        }
'''+needle+'''
                        rxExportActive=false;''')
radio.write_text(s)
packet_h=src/'src/packet.h';s=packet_h.read_text();s=s.replace('\t\tuint64_t getTimestamp();','''\t\tuint64_t getTimestamp();
        // The existing payload header carries export time separately from the
        // legacy timestamp member used by radio following/synchronization.
        uint32_t getExportTimestamp();
        void setExportTimestamp(uint32_t timestamp);''',1);packet_h.write_text(s)
packet=src/'src/packet.cpp';s=packet.read_text();needle='uint64_t Packet::getTimestamp() {\n\treturn this->timestamp;\n}'
assert s.count(needle)==1
s=s.replace(needle,needle+'''
uint32_t Packet::getExportTimestamp() {
    return uint32_t(this->payload[1]) | (uint32_t(this->payload[2])<<8) |
        (uint32_t(this->payload[3])<<16) | (uint32_t(this->payload[4])<<24);
}
void Packet::setExportTimestamp(uint32_t timestamp) {
    for (unsigned i=0;i<4;++i) this->payload[1+i]=uint8_t(timestamp>>(8*i));
}
''');packet.write_text(s)
controller=src/'src/controller.cpp';s=controller.read_text();assert s.count('frame.timestamp=packet->getTimestamp();')==1
s=s.replace('frame.timestamp=packet->getTimestamp();','frame.timestamp=packet->getExportTimestamp();');controller.write_text(s)
ble=src/'src/controllers/blecontroller.cpp';s=ble.read_text()
needle='\t\tBLEPacket *pkt = new BLEPacket(this->accessAddress,buffer, size,timestamp, relativeTimestamp, 0, this->channel,rssi, crcValue);'
assert s.count(needle)==1
s=s.replace(needle,needle+'''
        uint32_t exportStart;
        if (radioCurrentRxHardwareStart(timestamp,&exportStart))
            pkt->setExportTimestamp(exportStart);''');ble.write_text(s)
version=src/'src/version.h';version.write_text(version.read_text().replace('#define VERSION_REVISION 128','#define VERSION_REVISION 129'))
files=['src/radio.h','src/radio.cpp','src/packet.h','src/packet.cpp','src/controller.cpp','src/controllers/blecontroller.cpp','src/version.h']
subprocess.run(['git','add',*files],cwd=src,check=True)
subprocess.run(['git','commit','-m','Export PPI-latched RX time without changing legacy connection clocks'],cwd=src,check=True,capture_output=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()
out=dict(at=datetime.datetime.now().astimezone().isoformat(),baseCommit=parent,candidateCommit=commit,source=str(src),changedFiles=files,
    sourceSha256={n:hashlib.sha256((src/n).read_bytes()).hexdigest() for n in files},installed=False,
    scope='Raw export timestamp only. Existing packet payload-header storage avoids object/queue size changes. getTimestamp, PassiveFrame, crypto, anchors, hopping, RF configuration and product firmware stay unchanged. Relative timestamp field retains legacy clock. Hardware END pipeline offset is not an absolute calibrated antenna time.')
(R/'prepared-rxtiming129-source.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
