"""One bounded same-FW31 prime for new-peer RF binding, never a speed result."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,sys,time
import psutil
from receiver_session import request
R=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--receiver-revision',type=int,choices=(127,128,129),default=127);parser.add_argument('--hopping',action='store_true');parser.add_argument('--unfiltered-radio-check',action='store_true');parser.add_argument('--channel',type=int,choices=(37,38,39),default=37);args=parser.parse_args();assert not (args.hopping and args.unfiltered_radio_check)
OUT=R/('f834-bootstrap-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));OUT.mkdir()
APP=Path('C:/Program Files/Listener Type/listener-type.exe')
assert hashlib.sha256(APP.read_bytes()).hexdigest()=='59ca7597c20c5627c173bd8270a4934399eea3fda3d3d19b7dd8e809150a55a2'
def identities():return sorted((p.pid,p.create_time()) for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower()=='listener-type.exe')
receipt={'startedAt':datetime.datetime.now().astimezone().isoformat(),'typeBefore':identities(),'image':'same current FW31','speedClaim':False,'typeQuit':False,'pairingReset':False,'manualReset':False}
receipt['advertisingMode']='radio-check-unfiltered' if args.unfiltered_radio_check else 'hop' if args.hopping else 'fixed'+str(args.channel)
collector=None; capture=None
def save():(OUT/'round.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
save()
try:
    status=request({'action':'status'});assert status['ok'] and not status['owner'].get('captureActive')
    assert status['owner']['initialInfo']['firmware']==f'1.1.{args.receiver_revision}', 'Actual receiver revision mismatch; no collection or OTA'
    receipt['receiverRevision']=args.receiver_revision;save()
    with (OUT/'collector.log').open('wb') as log:
        command=[sys.executable,str(R/'passive_current_round.py'),'--seconds','300','--channel',str(args.channel),'--usb-events','--target-address','F83469CA5C53']
        command.append('--radio-check' if args.unfiltered_radio_check else '--tracking-only')
        if not (args.hopping or args.unfiltered_radio_check):command.append('--fixed-advertising')
        collector=subprocess.Popen(command,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
    end=time.monotonic()+18
    while time.monotonic()<end:
        assert collector.poll() is None,'Capture failed before product action'
        for line in (OUT/'collector.log').read_text(encoding='utf-8').splitlines():
            try:v=json.loads(line)
            except ValueError:continue
            if v.get('output'):capture=Path(v['output'])
        if capture and (capture/'rf-private/capture.json').exists():
            m=json.loads((capture/'rf-private/capture.json').read_text())
            if m.get('ready') and (m.get('radioCheckOnly') if args.unfiltered_radio_check else m.get('trackingOnly')):break
        time.sleep(.1)
    else:raise TimeoutError('Capture readiness not observed')
    receipt['capture']=str(capture);save()
    with (OUT/'prime-controller.log').open('wb') as log:
        command=[sys.executable,str(R/'ota_with_active_capture.py'),'--capture-round',str(capture),'--daily54-fw31','--daily-image','current31','--receiver-revision',str(args.receiver_revision),'--target-address','F8:34:69:CA:5C:53','--advertising-mode','hop' if args.hopping else 'fixed','--prime-unmeasured','--bootstrap-tracking','--execute-authorized-maintenance']
        if args.unfiltered_radio_check:command.append('--radio-check-bootstrap')
        result=subprocess.run(command,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW,timeout=100)
    receipt['controllerExit']=result.returncode
    transfer=capture/'unmeasured-current31/transfer.json'
    if transfer.exists():receipt['transfer']=json.loads(transfer.read_text())
    save()
    time.sleep(5)
except BaseException as error:
    receipt['error']=type(error).__name__+': '+str(error);save()
finally:
    if capture and (capture/'collection.json').exists():
        job=json.loads((capture/'collection.json').read_text()).get('captureJob')
        if job:receipt['captureStop']=request({'action':'captureStop','job':job})
    if collector:
        try:receipt['collectorExit']=collector.wait(timeout=30)
        except subprocess.TimeoutExpired:receipt['collectorStillRunning']=True
    receipt.update(typeAfter=identities(),finishedAt=datetime.datetime.now().astimezone().isoformat())
    receipt['typePreserved']=receipt['typeBefore']==receipt['typeAfter'];save()
print(json.dumps({'output':str(OUT),'capture':str(capture),'error':receipt.get('error'),'controllerExit':receipt.get('controllerExit'),'typePreserved':receipt['typePreserved']}))
