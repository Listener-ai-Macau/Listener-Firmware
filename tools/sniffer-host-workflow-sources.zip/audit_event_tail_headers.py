"""Relate actual repeated RF data to preceding MD/ACK headers, metadata only.

No missing ACK is treated as proven absence; no exact event boundaries inferred
from channels. Reuses independently full-image CRC/MIC-qualified recordings.
"""
from pathlib import Path
import bisect,collections,datetime,hashlib,json
from fresh_rf_gate import wire_crc
R=Path(__file__).resolve().parent
runs=['passive-current-20261019-163126','passive-current-20261019-163459','passive-current-20261019-164650']
reports=[]
for run in runs:
 root=R/run/'rf-private';proof=json.loads((root/'current-bond-independent-rf-proof.json').read_text());meta=json.loads((root/'rf-transport-metadata.json').read_text())
 source=root/'packets-private.jsonl';assert hashlib.sha256(source.read_bytes()).hexdigest()==proof['sourcePacketsSha256']==meta['sourceSha256']
 epoch=next(e for e in proof['epochs'] if e['fullImageRfCoverageQualified']);aa=epoch['aa']
 chunks=[c for c in meta['canonicalImageChunks'] if c['aa']==aa];assert len(chunks)==3908 and sum(c['bytes'] for c in chunks)==1731024
 first,last=min(c['firstUs'] for c in chunks),max(c['lastUs'] for c in chunks)
 micros={p['us']:p for p in meta['micVerifiedPackets'] if p['aa']==aa}
 frames=[];seed=None
 for line in source.read_text().splitlines():
  row=json.loads(line);p=bytes.fromhex(row['pdu'])
  if row['aa']=='8e89bed6' and len(p)==36 and p[0]&15==5 and f'{int.from_bytes(p[14:18],"little"):08x}'==aa and wire_crc(p,0x555555)==row['crc']:seed=int.from_bytes(p[18:21],'big')
  if row['aa']!=aa or not first<=row['deviceTimestampUs']<=last:continue
  assert seed is not None
  if not row['crcValid'] or len(p)!=2+p[1] or wire_crc(p,seed)!=row['crc']:continue
  frames.append(dict(us=row['deviceTimestampUs'],end=row['deviceTimestampUs']+(11+p[1])*4,ch=row['channel'],
    sn=(p[0]>>3)&1,nesn=(p[0]>>2)&1,md=(p[0]>>4)&1,llid=p[0]&3,bytes=p[1],
    mic=micros.get(row['deviceTimestampUs']),direction=row['direction'],cipher=p[2:]))
 central=[(i,f) for i,f in enumerate(frames) if f['mic'] and f['mic']['direction']==1 and f['llid'] in (1,2)]
 prior={};counts=collections.Counter();examples=[]
 for cindex,(i,f) in enumerate(central):
  m=f['mic'];key=(m['session'],m['counter'],m['sn']);old=prior.get(key);prior[key]=(cindex,i,f)
  if old is None:continue
  oi,fi,old=old
  if f['ch']==old['ch'] or f['us']-old['us']<=500:continue
  assert f['cipher']==old['cipher']
  counts['repeats']+=1;counts['originalMd'+str(old['md'])]+=1;counts['repeatedMd'+str(f['md'])]+=1
  prev=central[oi-1][1] if oi else None
  sameprev=prev is not None and prev['ch']==old['ch'] and 0<old['us']-prev['us']<2500
  if sameprev:counts['priorSameChannelCentralMd'+str(prev['md'])]+=1
  else:counts['noNearbyPriorCentralObserved']+=1
  replies=[]
  if sameprev:
   for z in frames[central[oi-1][0]+1:fi]:
    if z['ch']==prev['ch'] and 0<=z['us']-prev['end']<=450 and (z['direction']==2 or (z['mic'] and z['mic']['direction']==0) or (z['bytes']==0 and z['direction']==0)):
     replies.append(z)
   if replies:
    ack=replies[0]
    if ack['direction']==0:counts['priorCrcEmptyRoleInferredFromAdjacency']+=1
    counts['priorPeerMd'+str(ack['md'])]+=1
    if prev['md']==0 and ack['md']==0:counts['bothMd0BeforeRepeatedTail']+=1
    if ack['nesn']==prev['sn']^1:counts['priorPeerAckToggle']+=1
  after=frames[fi+1:i]
  nextcentral=next((z for z in after if z['mic'] and z['mic']['direction']==1),None)
  if nextcentral:after=[z for z in after if z['us']<nextcentral['us']]
  tailacks=[z for z in after if z['ch']==old['ch'] and 0<=z['us']-old['end']<=450 and (z['direction']==2 or (z['mic'] and z['mic']['direction']==0) or (z['bytes']==0 and z['direction']==0))]
  if not tailacks:counts['noObservedTimelyTailReply']+=1
  elif any(z['nesn']==old['sn']^1 for z in tailacks):counts['observedTailAckToggle']+=1
  else:counts['observedTailReplyStaleNesn']+=1
  if len(examples)<3:
   start=max(0,central[max(0,oi-2)][0]);end=min(len(frames),i+2)
   examples.append([dict(deltaUs=z['us']-old['us'],channel=z['ch'],bytes=z['bytes'],llid=z['llid'],sn=z['sn'],nesn=z['nesn'],md=z['md'],source='central_mic' if z['mic'] and z['mic']['direction']==1 else 'peripheral_mic' if z['mic'] else 'crc_only_direction_'+str(z['direction'])) for z in frames[start:end]])
 reports.append(dict(capture=run,sourceSha256=proof['sourcePacketsSha256'],counts=dict(counts),metadataExamples=examples))
report=dict(at=datetime.datetime.now().astimezone().isoformat(),runs=reports,
 scope='Actual CRC-checked headers and MIC-authenticated nonempty payload repetitions. Role0 empty packets within450us on the same channel are adjacency-inferred reply candidates, not authenticated direction. Header MD/NESN are not cryptographically authenticated; absent captured ACK does not prove peripheral silence. Channels/proximity approximate events; IRQ-derived timestamps are not exact air boundaries. No product/controller fault is asserted.')
(R/'event-tail-md-ack-audit.json').write_text(json.dumps(report,indent=2));print(json.dumps([dict(capture=x['capture'],counts=x['counts']) for x in reports],indent=2))
