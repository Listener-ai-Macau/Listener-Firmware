"""Program only a prepared app onto the exact already identified analyzer DFU."""
from pathlib import Path
import argparse, datetime, hashlib, json, subprocess, time
from serial.tools import list_ports

parser=argparse.ArgumentParser()
parser.add_argument('--revision',type=int,choices=(106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129),default=106)
args=parser.parse_args()
r = Path(__file__).resolve().parent
prepared = json.loads((r/(f'prepared-custom-{args.revision}.json' if args.revision!=106 else 'prepared-custom-candidate.json')).read_text())
image = r/prepared['package']
assert prepared['firmware'] == f'1.1.{args.revision}' and prepared['applicationOnly']
assert not prepared['bootloaderWritten']
assert hashlib.sha256(image.read_bytes()).hexdigest() == prepared['packageSha256']
assert hashlib.sha256((r/'restore-nordic-4.1.1.zip').read_bytes()).hexdigest() == prepared['restoredNordicPackageSha256']
ports = [p for p in list_ports.comports() if (p.vid,p.pid)==(0x1915,0x521f)]
assert len(ports)==1 and ports[0].serial_number=='C06430228A01', 'Exact analyzer DFU missing; no flash attempted'
result = dict(startedAt=datetime.datetime.now().astimezone().isoformat(),
    serial='C06430228A01', dfuPort=ports[0].device,
    applicationOnly=True, ListenerOperations=0, TypeQuitRequested=False,
    packageSha256=prepared['packageSha256'], sourceCommit=prepared['sourceCommit'])
cmd = ['C:/Users/Billy/.nrfutil/bin/nrfutil.exe','device','program',
       '--firmware',str(image.resolve()),'--serial-number','C06430228A01']
with (r/f'custom-candidate{args.revision}-program.log').open('wb') as log:
    result['programExit'] = subprocess.run(cmd,stdout=log,stderr=log,timeout=60).returncode
until=time.monotonic()+15
found=[]
while time.monotonic()<until:
    found=[dict(port=p.device,vid=p.vid,pid=p.pid,serial=p.serial_number,product=p.product)
           for p in list_ports.comports() if (p.vid,p.pid)==(0xc0ff,0xeeee)
           and p.serial_number=='C06430228A01']
    if found: break
    time.sleep(.5)
result.update(candidateUsbDevices=found,completedAt=datetime.datetime.now().astimezone().isoformat())
(r/f'custom-candidate{args.revision}-installed.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
assert result['programExit']==0 and len(found)==1
