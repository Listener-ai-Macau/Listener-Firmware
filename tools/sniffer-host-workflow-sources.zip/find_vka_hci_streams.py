"""Discover VKA1 notification streams without assuming an HCI/GATT handle.

Only handle/attribute/count metadata leaves memory. Peer identity must be joined
to the explicitly selected device log; a VKA1 magic prefix does not bind a peer.
"""
import collections, json, subprocess, sys
from pathlib import Path

def discover(pcap):
    cmd=['C:/Program Files/Wireshark/tshark.exe','-r',str(pcap),'-Y','btatt.opcode == 0x1b',
        '-T','fields','-e','bthci_acl.chandle','-e','btatt.handle','-e','btatt.value']
    streams=collections.Counter()
    for line in subprocess.check_output(cmd,text=True,timeout=45).splitlines():
        fields=line.split('\t')
        if len(fields)!=3:continue
        try:
            handle=int(fields[0],0);attribute=int(fields[1],0)
            value=bytes.fromhex(fields[2].replace(':',''))
        except ValueError:continue
        if value.startswith(b'VKA1'):streams[(handle,attribute)]+=1
    return [dict(connectionHandle=hex(h),attributeHandle=hex(a),vkaNotifications=n)
        for (h,a),n in sorted(streams.items())]

if __name__=='__main__':
    print(json.dumps(discover(Path(sys.argv[1]))))
