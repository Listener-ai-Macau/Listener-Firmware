"""Bounded, receive-only RF + HCI collection; never asks Type or Listener to reconnect."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, subprocess, sys, time, uuid
import psutil

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from receiver_session import request
from fresh_rf_gate import inspect

parser_args = argparse.ArgumentParser()
parser_args.add_argument('--seconds', type=int, default=600)
parser_args.add_argument('--target-address', default='F0515BAFB86A')
parser_args.add_argument('--tracking-only', action='store_true')
parser_args.add_argument('--channel', type=int, choices=(37,38,39), default=38)
parser_args.add_argument('--fixed-advertising', action='store_true')
parser_args.add_argument('--usb-events', action='store_true')
parser_args.add_argument('--usb-transfer-headers', action='store_true')
parser_args.add_argument('--radio-check', action='store_true')
args = parser_args.parse_args()
assert not args.radio_check or not args.tracking_only
assert not args.usb_transfer_headers or args.usb_events
seconds = args.seconds
assert 1 <= seconds <= 600
authenticate_rf = not (args.tracking_only or args.radio_check)

out = ROOT / ('passive-current-' + datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))
out.mkdir()
sid = subprocess.check_output(['whoami', '/user', '/fo', 'csv', '/nh'], text=True).strip().split(',')[1].strip('"')
subprocess.run(['icacls', str(out), '/inheritance:r', '/grant:r', '*' + sid + ':(OI)(CI)F', 'SYSTEM:(OI)(CI)F'], check=True, stdout=subprocess.DEVNULL)
def identities():
    return [{'pid': p.pid, 'started': p.create_time()} for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower() == 'listener-type.exe']
receipt = dict(startedAt=datetime.datetime.now().astimezone().isoformat(), typeBefore=identities(), productCommands=0, otaRequested=False, reconnectRequested=False, focusOperations=0, seconds=seconds, channel=args.channel, fixedAdvertising=args.fixed_advertising, collectorSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
instance = 'ListenerPassive' + uuid.uuid4().hex[:10]
def run(cmd, name, timeout=60):
    with (out / name).open('wb') as log:
        return subprocess.run(cmd, stdout=log, stderr=log, timeout=timeout, creationflags=subprocess.CREATE_NO_WINDOW).returncode
def save():
    (out / 'collection.json').write_text(json.dumps(receipt, indent=2))
started = False
usb_started = False
usb_instance = 'ListenerRxUsb' + uuid.uuid4().hex[:10]
job = None
try:
    owner = request({'action': 'status'})
    assert owner['ok'] and owner['owner']['running'] and not owner['owner'].get('captureActive', False)
    receipt['receiverBefore'] = owner['owner']
    profile = ROOT.parents[1] / 'work/ble-rename-repair-20261016/windows-hci/BluetoothStack.wprp'
    receipt['hciStartExit'] = run(['wpr', '-start', str(profile) + '!BluetoothStack', '-filemode', '-instancename', instance], 'hci-start.log')
    assert receipt['hciStartExit'] == 0
    started = True
    if args.usb_events:
        receipt['usbInstance']=usb_instance
        receipt['usbStartExit']=run(['logman','start',usb_instance,'-p','Microsoft-Windows-USB-USBHUB3','0x861b','4','-o',str(out/'receiver-usb.etl'),'-ets','-f','bincirc','-max','64','-bs','64','-nb','16','64'],'usb-start.log')
        assert receipt['usbStartExit']==0,'USB lifecycle trace failed; no product action'
        usb_started=True
        if args.usb_transfer_headers:
            # Headers only: no PartialDataBusTrace/FullDataBusTrace payloads.
            # HUB3 alone cannot show CDC control transfers preceding removal.
            receipt['usbTransferHeaderProviders']={}
            for provider in ('Microsoft-Windows-USB-UCX','Microsoft-Windows-USB-USBXHCI'):
                code=run(['logman','update','trace','-n',usb_instance,'-p',provider,'0xb845f','5','-ets'],provider+'.log')
                receipt['usbTransferHeaderProviders'][provider]=code
                assert code==0,'USB transfer header provider failed; no product action'
    save()
    print(json.dumps({'output': str(out), 'receiveOnly': True}), flush=True)
    since = time.time()
    launch = request({'action': 'captureStart', 'seconds': seconds, 'channel': args.channel, 'output': str(out / 'rf-private'), 'passiveKey': not (args.tracking_only or args.radio_check), 'radioCheck': args.radio_check, 'trackingOnly': args.tracking_only, 'fixedAdvertising': args.fixed_advertising, 'targetAddress': args.target_address})
    assert launch['ok'], launch.get('error')
    job = launch['job']; receipt['captureJob'] = job; save()
    until = time.monotonic() + seconds + 8
    while time.monotonic() < until:
        state = request({'action': 'captureStatus', 'job': job})
        assert state['ok'], state.get('error')
        if state['done']: break
        if authenticate_rf and not receipt.get('freshRfAdmission', {}).get('admitted'):
            gate = inspect(out / 'rf-private/packets-private.jsonl', since)
            if gate['admitted']:
                receipt['freshRfAdmission'] = gate; save()
                print(json.dumps({'freshRfAdmission': gate, 'otaRequested': False}), flush=True)
        time.sleep(.5)
    else: raise TimeoutError('Receiver job did not complete within the bounded collection window')
    result = state['result']
    receipt['rfOk'] = result['ok']
    receipt['capture'] = result.get('capture')
    receipt['receiverAfter'] = request({'action': 'status'})['owner']
    if not result['ok']: receipt['error'] = result['error']
except BaseException as error:
    receipt['error'] = type(error).__name__ + ': ' + str(error)
finally:
    if job is not None:
        state = request({'action': 'captureStatus', 'job': job})
        if state['ok'] and not state['done']:
            request({'action': 'captureStop', 'job': job})
            until = time.monotonic() + 4
            while time.monotonic() < until:
                if request({'action': 'captureStatus', 'job': job})['done']: break
                time.sleep(.05)
    if started:
        receipt['hciStopExit'] = run(['wpr', '-stop', str(out / 'hci-private.etl'), '-skipPdbGen', '-instancename', instance], 'hci-stop.log')
    if usb_started:
        receipt['usbStopExit']=run(['logman','stop',usb_instance,'-ets'],'usb-stop.log')
    receipt.update(typeAfter=identities(), completedAt=datetime.datetime.now().astimezone().isoformat())
    receipt['typeUnchanged'] = receipt['typeBefore'] == receipt['typeAfter']
    save()
if receipt.get('hciStopExit') == 0:
    parser = ROOT.parents[1] / 'work/ble-rename-repair-20261016/windows-hci/btp-extracted/BTP/v1.14.0/x64/BTETLParse.exe'
    receipt['hciParseExit'] = run([str(parser), '-pcapng', str(out / 'hci-private.pcapng'), str(out / 'hci-private.etl')], 'hci-parse.log')
    save()
if receipt.get('rfOk') and authenticate_rf:
    receipt['rfProofExit'] = run([sys.executable, str(ROOT / 'verify_current_capture.py'), '--capture', str(out / 'rf-private')], 'rf-proof.log')
    save()
print(json.dumps({'output': str(out), 'rfOk': receipt.get('rfOk'), 'typeUnchanged': receipt['typeUnchanged'], 'productCommands': 0, 'hciParseExit': receipt.get('hciParseExit')}), flush=True)
