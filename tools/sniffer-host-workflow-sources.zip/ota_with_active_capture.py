"""One authorized raw FW22 OTA inside an already-running RF/HCI collection.

Default is prepare-only. Never opens COM, creates another trace, quits Type,
or changes pairing/name. Measured OTA requires fresh authenticated RF.
The separately authorized prime mode is explicitly unmeasured: it replays the
same original image once to observe its normal post-update reconnection.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess,sys,threading,time,uuid
import psutil
R=Path(__file__).resolve().parent;W=R.parents[1]
sys.path.insert(0,str(R));from receiver_session import request
from fresh_rf_gate import inspect_recent
sys.path.insert(0,'C:/Users/Billy/Desktop/Denzic/Listener/Listener-Type/scripts')
from shared_log_reader import open_shared_log
P=argparse.ArgumentParser();P.add_argument('--capture-round',type=Path);P.add_argument('--execute-authorized-maintenance',action='store_true');P.add_argument('--await-new-link-seconds',type=int,default=0);P.add_argument('--receiver-revision',type=int,choices=(121,122,123,124,125,126,127),default=121);P.add_argument('--prime-unmeasured',action='store_true');P.add_argument('--advertising-mode',choices=('fixed','hop'),default='fixed');P.add_argument('--target-address',default='F0:51:5B:AF:B8:6A');P.add_argument('--bootstrap-tracking',action='store_true');P.add_argument('--install-ce27',action='store_true',help='Only install the pinned isolated CE27 image as an unmeasured preparation; never a measured baseline');P.add_argument('--raw215-narrow-time-trial',action='store_true');P.add_argument('--type53-raw215-trial',action='store_true');P.add_argument('--install-security28',action='store_true',help='Pinned FW28 bonded encryption grace candidate; unmeasured installation only');P.add_argument('--install-ce29',action='store_true',help='Pinned CE29 ORIGINAL0 with verified security28; unmeasured only');P.add_argument('--daily54-fw31',action='store_true');P.add_argument('--daily-image',choices=('original22','current31','daily32','daily33'),default='original22');P.add_argument('--radio-check-bootstrap',action='store_true');a=P.parse_args()
# The candidate is only installed in a separately labelled, unmeasured step.
# The measured image and default runtime hashes below remain the FW22 baseline.
assert not a.bootstrap_tracking or a.prime_unmeasured, 'Bootstrap cannot authorize measured OTA'
assert not a.install_security28 or (a.prime_unmeasured and not a.install_ce27 and not a.type53_raw215_trial and not a.bootstrap_tracking), 'FW28 must be isolated unmeasured installation'
assert sum([a.install_ce27,a.install_security28,a.install_ce29])<=1
assert not a.install_ce29 or (a.prime_unmeasured and not a.type53_raw215_trial and not a.bootstrap_tracking), 'FW29 must be isolated unmeasured installation'
assert not a.radio_check_bootstrap or (a.daily54_fw31 and a.daily_image=='current31' and a.prime_unmeasured and a.bootstrap_tracking), 'Unfiltered diagnostics can only prime unchanged daily31, never authorize measured/candidate data'
TARGET=a.target_address.replace(':','').lower();assert len(TARGET)==12 and all(c in '0123456789abcdef' for c in TARGET)
assert 0<=a.await_new_link_seconds<=480
assert not a.prime_unmeasured or a.await_new_link_seconds==0
APP=Path('C:/Program Files/Listener Type/listener-type.exe')
PACKAGE=W/'outputs/firmware-audio-block22-20261017/listener-ota-1.0.6-rc1-20261017-181137'
IMAGE=PACKAGE/'firmware_ota.bin';MANIFEST=PACKAGE/'ota_manifest.json'
EXPECTED_APP_SHA='9f20cbe040c93b6c5763277ff7496964a3bb459fd045e933d243efbe5faa2a7e'
if a.type53_raw215_trial:
    prepared_type=json.loads((R/'prepared-type53-raw215.json').read_text())
    assert prepared_type['candidateCommit']=='2699d62e11f9549e98806a1eef5c2deca35924c8'
    assert not a.install_ce27 and not a.raw215_narrow_time_trial
    EXPECTED_APP_SHA=prepared_type['artifactExeSha256']
if a.daily54_fw31:
    assert TARGET=='f83469ca5c53', 'Daily54 peer must be explicitly revalidated F8'
    assert not any((a.install_ce27,a.install_ce29,a.install_security28,a.type53_raw215_trial,a.raw215_narrow_time_trial)), 'No stale pre-settings candidate under daily54'
    daily_baseline=json.loads((R/'daily-baseline-type54-fw31.json').read_text())
    EXPECTED_APP_SHA=daily_baseline['dailyTypeExeSha256']
    assert EXPECTED_APP_SHA=='59ca7597c20c5627c173bd8270a4934399eea3fda3d3d19b7dd8e809150a55a2'
else:
    assert a.daily_image=='original22', 'Daily images require explicit daily54 profile'
assert hashlib.sha256(APP.read_bytes()).hexdigest()==EXPECTED_APP_SHA
EXPECTED_IMAGE_SHA='5ada03ae6929927393e49438088cbd78e26283cd283326ce71f41c43d9a24550'
if a.install_ce27:
    assert a.prime_unmeasured and not a.bootstrap_tracking, 'Candidate installation is unmeasured preparation only'
    prepared=json.loads((R/'prepared-ce27.json').read_text())
    assert prepared['baseCommit']=='368d320ef9ea0ed634de2eda5d2c37d502326ab0' and prepared['buildExit']==0 and prepared['configDeltaOnlyCeMode']
    EXPECTED_IMAGE_SHA='a71ee7ca85427e88075ed1f38763a99793f81f6d5d4c3a348e5a382ed7ec2733'
    assert prepared['imageSha256']==EXPECTED_IMAGE_SHA
    PACKAGE=Path(prepared['package']);IMAGE=PACKAGE/'firmware_ota.bin';MANIFEST=PACKAGE/'ota_manifest.json'
if a.install_security28:
    prepared=json.loads((R/'prepared-security28.json').read_text())
    assert prepared['baseCommit']=='368d320ef9ea0ed634de2eda5d2c37d502326ab0'
    assert prepared['buildExit']==0 and prepared['configMatchesFw22'] and not prepared['configDelta']
    EXPECTED_IMAGE_SHA='47cd578e9c65037a1dcb607621a6532d00d13c968e7dc29827e2fa5cf833624f'
    assert prepared['imageSha256']==EXPECTED_IMAGE_SHA
    PACKAGE=Path(prepared['package']);IMAGE=PACKAGE/'firmware_ota.bin';MANIFEST=PACKAGE/'ota_manifest.json'
if a.install_ce29:
    prepared=json.loads((R/'prepared-ce29.json').read_text())
    assert prepared['baseCommit']=='c0e28bcd695a19cfdd33989bc727bd2ab660141b'
    assert prepared['buildExit']==0 and prepared['configDeltaOnlyCeMode']
    EXPECTED_IMAGE_SHA='3ea87dc32fd04990dcb7bf9e2bb6b079a4c9e81c056f4a6c2febdc7fd850d2b8'
    assert prepared['imageSha256']==EXPECTED_IMAGE_SHA
    PACKAGE=Path(prepared['package']);IMAGE=PACKAGE/'firmware_ota.bin';MANIFEST=PACKAGE/'ota_manifest.json'
if a.daily_image!='original22':
    assert a.daily54_fw31 and a.prime_unmeasured, 'Candidate/current image uploads are unmeasured preparation only'
    receipt=json.loads((R/('prepared-settings31.json' if a.daily_image=='current31' else 'prepared-'+a.daily_image+'.json')).read_text())
    assert receipt['buildExit']==0 and not receipt['configDelta'], 'Exact generated SDK configuration required'
    if a.daily_image!='current31':
        assert receipt['baseSourceCommit']=='b8311a73fcf4e37c78d6d83273e96f9b34eb605a'
        assert not a.bootstrap_tracking, 'Only current31 bootstrap may precede RF authentication'
    PACKAGE=Path(receipt['package']);IMAGE=PACKAGE/'firmware_ota.bin';MANIFEST=PACKAGE/'ota_manifest.json'
    EXPECTED_IMAGE_SHA=receipt['imageSha256']
assert hashlib.sha256(IMAGE.read_bytes()).hexdigest()==EXPECTED_IMAGE_SHA
if a.raw215_narrow_time_trial:
    raise ValueError('Installed Type requires manifest500; prior215-manifest attempt rejected before BLE. Do not retry or relax release validation.')
    assert not a.install_ce27 and a.prime_unmeasured, '215 geometry trial is original-image, retrospectively qualified only'
    MANIFEST=R/'raw215-narrow-time/ota_manifest.json'
    trial=json.loads(MANIFEST.read_text())
    assert trial['requirements']['gatt_chunk_bytes']==trial['protocol']['gatt']['chunk_bytes']==215
    assert trial['firmware']['sha256']==EXPECTED_IMAGE_SHA
assert MANIFEST.is_file()
ident=lambda:sorted((p.pid,p.create_time()) for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower()=='listener-type.exe')
meta=dict(at=datetime.datetime.now().astimezone().isoformat(),rawImageBytes=IMAGE.stat().st_size,compressed=False,typeBefore=ident(),typeQuitRequested=False,otaRequested=False,receiverFirmwareWrites=0,productNameOrPairingChanges=0,requiredReceiverFirmware=f'1.1.{a.receiver_revision}',targetAddress=TARGET,bootstrapTracking=a.bootstrap_tracking,advertisingMode=a.advertising_mode,primeUnmeasured=a.prime_unmeasured,purpose='Original-image prime to observe normal post-update reconnect; not an RF measurement' if a.prime_unmeasured else 'Measured original-image OTA requiring fresh sustained authenticated RF')
meta.update(candidateInstallation=a.install_ce27 or a.install_security28 or a.install_ce29,ce29Installation=a.install_ce29,security28Installation=a.install_security28,imageSha256=EXPECTED_IMAGE_SHA,type53Raw215Trial=a.type53_raw215_trial,runtimeExeSha256=EXPECTED_APP_SHA,raw215NarrowTimeTrial=a.raw215_narrow_time_trial,manifestSha256=hashlib.sha256(MANIFEST.read_bytes()).hexdigest())
if a.raw215_narrow_time_trial:meta['purpose']='Original image215-byte trial; narrow-time hypothesis requires actual RF/HCI budget proof after transfer, no pre-admitted measurement claim'
if a.install_ce29:meta['purpose']='Install isolated FW29 CE-ORIGINAL0 candidate; unmeasured preparation, not a speed result'
if a.install_security28:meta['purpose']='Install isolated FW28 bonded encryption grace; unmeasured preparation, not a speed result'
if a.install_ce27:meta['purpose']='Install isolated controller CE27 candidate; unmeasured preparation, not a speed result'
meta.update(daily54Fw31=a.daily54_fw31,dailyImageChoice=a.daily_image)
if a.daily54_fw31:
    meta['preservedDailyBaseline']='Type54 / FW31 full settings snapshot; never restore22 as final daily firmware'
if a.daily_image!='original22':
    meta['purpose']='Unmeasured preparation/restore '+a.daily_image+'; not a throughput result'
if not a.execute_authorized_maintenance:
    print(json.dumps(dict(meta,prepareOnly=True,required=f'User-authorized short Bluetooth maintenance window, Type idle, RF{a.receiver_revision}/HCI active with fresh sustained current-peer DATA')));raise SystemExit(0)
assert a.capture_round is not None
ROUND=a.capture_round.resolve();assert ROUND.is_relative_to(R)
OUT=ROUND/(('unmeasured-'+a.daily_image) if a.daily_image!='original22' else ('unmeasured-install-ce29' if a.install_ce29 else 'unmeasured-install-security28' if a.install_security28 else 'unmeasured-install-ce27' if a.install_ce27 else 'unmeasured-prime-ota' if a.prime_unmeasured else 'actual-raw-ota'));OUT.mkdir(exist_ok=False)
# Inherit the collection directory's current-user/SYSTEM-only ACL.
save=lambda:(OUT/'transfer.json').write_text(json.dumps(meta,indent=2))
LOGS=Path('C:/Users/Billy/AppData/Local/Listener Type/Logs')
FW_EXPORT=Path('C:/Users/Billy/Desktop/Denzic/Listener/Listener-Firmware/tools/export_ble_diag_log.py')
def run(cmd,name,timeout=15):
    with (OUT/name).open('wb') as log:
        return subprocess.run(cmd,stdout=log,stderr=log,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW).returncode
def idle(label):
    token=str(uuid.uuid4());assert run([str(APP),'--diagnostic-dictation-snapshot',token],label+'.log',10)==0
    path=LOGS/'diagnostic-dictation-snapshot'/(token+'.json');until=time.monotonic()+5
    while not path.exists() and time.monotonic()<until:time.sleep(.05)
    value=json.loads(path.read_text(encoding='utf-8-sig'))
    assert not value.get('error') and value['servicePid'] in [x[0] for x in meta['typeBefore']]
    assert value['snapshot']['phase']=='idle' and not value['snapshot']['pendingStop'],'Recording active: OTA not started'
    (OUT/(label+'.json')).write_text(json.dumps(value,indent=2))
def firmware_diag(label,count):
    code=run([sys.executable,str(FW_EXPORT),'--address',a.target_address,'--count',str(count),'--scan-timeout','0.2','--notify-timeout','2','--output',str(OUT/(label+'.jsonl'))],label+'.log',15)
    meta[label+'Exit']=code;save();return code
def current_capture(*,since_epoch=None,require_sustained=True):
    collection=json.loads((ROUND/'collection.json').read_text());state=request({'action':'status'})
    assert state['ok'] and state['owner']['initialInfo']['firmware']==meta['requiredReceiverFirmware']
    assert state['owner'].get('captureActive') and state['owner']['activeJob']==collection['captureJob']
    assert collection['hciStartExit']==0
    end=datetime.datetime.fromisoformat(collection['startedAt']).timestamp()+collection['seconds']
    assert end-time.time()>70,'Capture has insufficient remaining duration: no OTA'
    c=json.loads((ROUND/'rf-private/capture.json').read_text())
    assert c['ready'] and c['firmware']==meta['requiredReceiverFirmware']
    assert (c.get('radioCheckOnly') and c.get('targetAddress') is None) if a.radio_check_bootstrap else c['targetAddress']==TARGET
    if a.bootstrap_tracking:
        assert not require_sustained and not c['passiveKeyLoaded']
        assert c.get('radioCheckOnly') if a.radio_check_bootstrap else c['trackingOnly']
    else:assert c['passiveKeyLoaded'] and c['peerKeyBindingQualified']
    if not a.radio_check_bootstrap:
        assert c['passiveAdvertisingHopping']==(a.advertising_mode=='hop'),'Actual advertising mode differs from explicitly requested acquisition mode'
    if a.bootstrap_tracking:return {'admitted':False,'sustainedReady':False,'scope':'Tracking-only current-peer bootstrap, not a measured transfer'}
    health=inspect_recent(ROUND/'rf-private/packets-private.jsonl',max(since_epoch or 0,datetime.datetime.fromisoformat(collection['startedAt']).timestamp()))
    meta['recentRfBeforeOta']=health;save()
    if require_sustained:assert health['sustainedReady'],health['reason']
    return health
stop=threading.Event();finished=threading.Event();observer=None;requested_after=None
def observe():
    stream=None;inode=None;partial=''
    try:
        with (OUT/'type-ota-events.log').open('w',encoding='utf-8',buffering=1) as out:
            while not stop.is_set():
                try:
                    path=LOGS/'listener-type.log';identity=path.stat().st_ino
                    if inode!=identity:
                        if stream:stream.close()
                        stream=open_shared_log(path);inode=identity;partial=''
                    parts=(partial+stream.read()).split('\n');partial=parts.pop()
                    for line in parts:
                        try:stamp=datetime.datetime.fromisoformat(line.split(' ',1)[0].replace('Z','+00:00'))
                        except ValueError:continue
                        if stamp<requested_after:continue
                        if any(k in line for k in ('[firmware-ota]','Listener OTA','firmware_ota_owned_result_json=','background listener notify ready')):out.write(line+'\n')
                        if 'firmware_ota_owned_result_json=' in line:
                            value=json.loads(line.split('firmware_ota_owned_result_json=',1)[1])
                            if value.get('servicePid') not in [x[0] for x in meta['typeBefore']]:continue
                            if value.get('status')=='PASS' and value['result']['bytesTransferred']!=IMAGE.stat().st_size:continue
                            meta['ownedResult']=value;meta['resultAt']=stamp.isoformat();save();finished.set()
                except OSError:pass
                stop.wait(.03)
    finally:
        if stream:stream.close()
try:
    assert len(meta['typeBefore'])==2,'Expected installed Type main and helper; no process is stopped'
    idle('idle-before-ota')
    if a.prime_unmeasured:
        assert firmware_diag('firmware-before',96)==0,'Device diagnostic read failed: no prime OTA'
        current_capture(require_sustained=False)
    elif a.await_new_link_seconds:
        # The collector is already running before this process is armed. A link
        # acquired during that startup gap belongs to this same collection;
        # do not reject it and force another physical restart.
        since=datetime.datetime.fromisoformat(json.loads((ROUND/'collection.json').read_text())['startedAt']).timestamp()
        until=time.monotonic()+a.await_new_link_seconds;diag_done=False
        meta['armedAt']=datetime.datetime.now().astimezone().isoformat();save()
        meta['armedUntil']=(datetime.datetime.now().astimezone()+datetime.timedelta(seconds=a.await_new_link_seconds)).isoformat();save()
        print(json.dumps({'armed':True,'untilSeconds':a.await_new_link_seconds,'armedUntil':meta['armedUntil'],'output':str(OUT)}),flush=True)
        while time.monotonic()<until:
            health=current_capture(since_epoch=since,require_sustained=False)
            if health['admitted'] and not diag_done:
                assert firmware_diag('firmware-before',96)==0,'Device diagnostic read failed: no OTA'
                diag_done=True
            if diag_done and health['sustainedReady']:break
            time.sleep(.2)
        else:raise TimeoutError('No fresh sustained link in the authorized bounded wait; OTA not started')
        current_capture(since_epoch=since)
    else:
        assert firmware_diag('firmware-before',96)==0,'Device diagnostic read failed: no OTA'
        current_capture()
    # Recheck idle immediately after decoding the bounded RF precondition.
    idle('idle-final');assert ident()==meta['typeBefore']
    requested_after=datetime.datetime.now(datetime.timezone.utc)
    meta['requestedAt']=requested_after.isoformat();save()
    observer=threading.Thread(target=observe);observer.start()
    # Exclusive marker prevents accidental duplicate replays in this collection.
    marker_name='install-ce29-request-once.json' if a.install_ce29 else 'install-security28-request-once.json' if a.install_security28 else 'install-ce27-request-once.json' if a.install_ce27 else 'prime-ota-request-once.json' if a.prime_unmeasured else 'ota-request-once.json'
    with (ROUND/marker_name).open('x') as marker:json.dump({'requestedAt':meta['requestedAt'],'imageSha256':hashlib.sha256(IMAGE.read_bytes()).hexdigest(),'primeUnmeasured':a.prime_unmeasured},marker)
    meta['otaRequested']=True;save()
    meta['requestExit']=run([str(APP),'--firmware-ota-transfer',str(MANIFEST),str(IMAGE)],'owned-request.log',15);save()
    finished.wait(60);meta['ownedResultObserved']=finished.is_set();save()
    if meta.get('ownedResult',{}).get('status')=='PASS':
        # Do not disturb a user who has already resumed speaking after OTA.
        try:idle('idle-before-device-result');firmware_diag('firmware-after',128)
        except AssertionError:meta['firmwareAfterSkipped']='User resumed recording or state unavailable';save()
except BaseException as error:
    import traceback
    meta['error']=type(error).__name__+': '+str(error);meta['errorTraceback']=traceback.format_exc();save()
finally:
    stop.set()
    if observer:observer.join(timeout=3)
    meta.update(completedAt=datetime.datetime.now().astimezone().isoformat(),typeAfter=ident())
    meta['typeUnchanged']=meta['typeBefore']==meta['typeAfter'];save()
print(json.dumps({'output':str(OUT),'otaRequested':meta['otaRequested'],'ownedResultObserved':meta.get('ownedResultObserved'),'typeUnchanged':meta['typeUnchanged'],'error':meta.get('error')}))
raise SystemExit(0 if meta.get('ownedResultObserved') else 2)
