"""Windows serial-only passive WHAD probe; no Linux select, active RF or product control.

This candidate tests the missing handshake boundary. It is not a certificate of
full encrypted/PHY-updated OTA following. Default self-check never opens hardware.
"""
from pathlib import Path
import argparse, collections, contextlib, datetime, hashlib, json, re, struct, sys, time, types
import serial
from serial.tools import list_ports

ROOT = Path(__file__).parent
pkg = types.ModuleType('whad')
pkg.__path__ = [str(ROOT / 'client/whad')]
sys.modules['whad'] = pkg
from whad.protocol import whad_pb2

ALLOWED = {('discovery', 'info_query'), ('discovery', 'reset_query'),
           ('ble', 'sniff_connreq'), ('ble', 'sniff_adv'), ('ble', 'start'), ('ble', 'stop')}


def wire(message):
    domain = message.WhichOneof('msg')
    kind = getattr(message, domain).WhichOneof('msg')
    passive_key = domain == 'ble' and kind == 'encryption'
    if passive_key:
        value = message.ble.encryption
        if (value.conn_handle not in (0xffff,0xfffe) or not value.enabled or
            value.ll_key != bytes(16) or value.ll_iv != bytes(8) or
            len(value.key) != 16 or len(value.rand) != 8 or len(value.ediv) != 2):
            raise ValueError('Only complete RAM-only passive key command is permitted')
    elif (domain, kind) not in ALLOWED:
        raise ValueError('This diagnostic permits receiver-only passive commands')
    payload = message.SerializeToString()
    return b'\xac\xbe' + struct.pack('<H', len(payload)) + payload


class Frames:
    def __init__(self):
        self.buffer = bytearray()
        self.discarded = 0

    def feed(self, data):
        self.buffer.extend(data)
        messages = []
        while len(self.buffer) >= 4:
            if self.buffer[:2] != b'\xac\xbe':
                del self.buffer[0]
                self.discarded += 1
                continue
            size = int.from_bytes(self.buffer[2:4], 'little')
            if size > 8192:
                raise ValueError('Unexpected WHAD frame length; stopping capture')
            if len(self.buffer) < size + 4:
                break
            msg = whad_pb2.Message()
            msg.ParseFromString(bytes(self.buffer[4:size+4]))
            messages.append(msg)
            del self.buffer[:size+4]
        return messages


def command(domain, kind):
    msg = whad_pb2.Message()
    getattr(getattr(msg, domain), kind).SetInParent()
    return msg


def self_check():
    query = command('discovery', 'info_query')
    query.discovery.info_query.proto_ver = 0x0100
    codec = Frames()
    expected = wire(query)
    messages = []
    with serial.serial_for_url('loop://', timeout=.1) as port:
        port.write(b'noise' + expected + expected)
        for _ in range(2 * len(expected) + 5):
            messages.extend(codec.feed(port.read(1)))
    assert len(messages) == 2 and all(x == query for x in messages)
    assert codec.discarded == 5
    refused = False
    try:
        wire(command('ble', 'send_raw_pdu'))
    except ValueError:
        refused = True
    assert refused
    bad_key = command('ble', 'encryption')
    try:
        wire(bad_key)
    except ValueError:
        pass
    else:
        raise AssertionError('Active encryption command was admitted')
    for handle in (0xffff,0xfffe,0):
        synthetic=command('ble','encryption').ble.encryption
        synthetic.conn_handle=handle; synthetic.enabled=True
        synthetic.ll_key=synthetic.key=bytes(16)
        synthetic.ll_iv=synthetic.rand=bytes(8); synthetic.ediv=bytes(2)
        envelope=command('ble','encryption');envelope.ble.encryption.CopyFrom(synthetic)
        try:
            wire(envelope)
            assert handle in (0xffff,0xfffe)
        except ValueError:
            assert handle==0
    print(json.dumps(dict(serialLoopback=True, fragmentedFrames=2,
                          activeRfCommandRejected=True, activeEncryptionRejected=True,
                          bothPassiveModesAdmitted=True,
                          hardwareOpened=False)))


def target_address_bytes(value):
    """Require the current, explicit peer; never silently follow a historic MAC."""
    normalized = (value or '').replace(':', '').replace('-', '').lower()
    if not re.fullmatch(r'[0-9a-f]{12}', normalized) or normalized in ('0'*12, 'f'*12):
        raise ValueError('Explicit current Listener target address required; no historic or wildcard fallback')
    return bytes.fromhex(normalized)[::-1]


def connection_sniff_command(channel, target_address):
    peer = target_address_bytes(target_address)
    msg = command('ble', 'sniff_connreq')
    msg.ble.sniff_connreq.channel = channel
    msg.ble.sniff_connreq.bd_address = peer
    msg.ble.sniff_connreq.show_advertisements = True
    msg.ble.sniff_connreq.show_empty_packets = True
    return msg


def passive_key_command(target_address):
    """Load only the already independently validated Listener bond; never export it."""
    if target_address_bytes(target_address) == bytes.fromhex('35b568f6b2cd'):
        from peer_binding import load
        reference, proof = load(target_address)
        msg=command('ble','encryption');value=msg.ble.encryption
        value.conn_handle,value.enabled=0xffff,True
        value.ll_key,value.ll_iv=bytes(16),bytes(8)
        value.key=bytes.fromhex(reference['keyBigEndian'][2:])
        value.rand,value.ediv=bytes.fromhex(reference['randHex']),bytes.fromhex(reference['edivHex'])
        wire(msg)
        return msg,proof['privateReferenceSha256']
    if target_address_bytes(target_address) == bytes.fromhex('6ab8af5b51f0'):
        return current_peer_key_command(target_address)
    if target_address_bytes(target_address) != bytes.fromhex('c381d9134bd7'):
        from peer_binding import load
        reference, proof = load(target_address)
        msg=command('ble','encryption');value=msg.ble.encryption
        value.conn_handle,value.enabled=0xffff,True
        value.ll_key,value.ll_iv=bytes(16),bytes(8)
        value.key=bytes.fromhex(reference['keyBigEndian'][2:])
        value.rand,value.ediv=bytes.fromhex(reference['randHex']),bytes.fromhex(reference['edivHex'])
        wire(msg)
        return msg,proof['privateReferenceSha256']
    workspace = Path('C:/Users/Billy/Documents/Codex/2026-10-04/listener-repair-handoff')
    sys.path.insert(0, 'C:/Users/Billy/Desktop/Denzic/Listener/Listener-Firmware/tools')
    from analyze_listener_air_refresh import validate_reference
    key, _, binding = validate_reference(
        workspace/'work/sniffer-fresh-bond-20261017-2151/current-bond-private.json',
        workspace/'work/sniffer-cold-ota-20261017-2144/known-key-verification-fresh.json')
    rows = (ROOT/'compare-channel38/live-air-private/packets-private.jsonl').read_text().splitlines()
    requests = [bytes.fromhex(x['pdu']) for line in rows for x in [json.loads(line)]
                if x['aa'] == '51b9820d' and x['crcValid']]
    request = next(x[2:] for x in requests if len(x) == 25 and x[2] == 3)
    msg = command('ble', 'encryption')
    value = msg.ble.encryption
    value.conn_handle, value.enabled = 0xffff, True
    value.ll_key, value.ll_iv = bytes(16), bytes(8)
    value.key, value.rand, value.ediv = key, request[1:9], request[9:11]
    wire(msg)  # Validate full arrays before any hardware write.
    return msg, binding


def current_peer_key_command(target_address):
    """A fresh read-only Windows leaf backup plus actual current-peer MIC proof."""
    if target_address_bytes(target_address) != bytes.fromhex('6ab8af5b51f0'):
        raise ValueError('Current bond cannot be used for another target')
    proof = json.loads((ROOT/'current-bond-mic-proof.json').read_text())
    reference_path = ROOT/'current-peer-bond-private/verified-current-bond.json'
    raw = reference_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != proof['privateReferenceSha256']:
        raise ValueError('Current bond reference differs from independent MIC proof')
    reference = json.loads(raw)
    if (proof['currentPeer'] != 'F0:51:5B:AF:B8:6A' or
        reference['listenerAddress'] != proof['currentPeer'] or
        reference['peerAddress'] != '68:34:21:92:02:24' or
        proof['localAdapter'] != reference['peerAddress'] or
        proof['totalMicVerified'] < 4 or
        sum(x['verifiedFrames'] >= 2 for x in proof['epochs']) < 2):
        raise ValueError('Missing independent current-peer identity/MIC binding')
    for name, digest in proof['sourcePacketSha256'].items():
        if hashlib.sha256((ROOT/name/'live-air-private/packets-private.jsonl').read_bytes()).hexdigest() != digest:
            raise ValueError('Current MIC proof RF source changed')
    key = bytes.fromhex(reference['keyBigEndian'][2:])
    rand, ediv = bytes.fromhex(reference['randHex']), bytes.fromhex(reference['edivHex'])
    if hashlib.sha256(rand+ediv).hexdigest() not in proof['lookupFingerprints']:
        raise ValueError('Current handshake lookup differs from authenticated RF')
    msg = command('ble', 'encryption')
    value = msg.ble.encryption
    value.conn_handle, value.enabled = 0xffff, True
    value.ll_key, value.ll_iv = bytes(16), bytes(8)
    value.key, value.rand, value.ediv = key, rand, ediv
    wire(msg)
    return msg, proof['privateReferenceSha256']


def tracking_only_command(*, fixed_advertising=True):
    """Enable the existing wide-RX/queued passive path without using any bond.

    The all-zero dummy key and impossible-for-this-trial lookup are not a peer
    identity credential. No authentication result from this mode is evidence.
    """
    msg = command('ble', 'encryption')
    value = msg.ble.encryption
    value.conn_handle, value.enabled = (0xfffe if fixed_advertising else 0xffff), True
    value.ll_key, value.ll_iv = bytes(16), bytes(8)
    value.key, value.rand, value.ediv = bytes(16), bytes([255])*8, bytes([255])*2
    wire(msg)
    return msg


def capture(port_name, output, seconds, channel=37, passive_key=False, radio_check=False, fixed_advertising=False, borrowed_port=None, target_address=None, tracking_only=False, stop_event=None):
    # Validate before opening or commanding hardware, including borrowed owners.
    sniff_target = None if radio_check else target_address_bytes(target_address)
    if passive_key:
        if radio_check:
            raise ValueError('Passive key cannot be combined with radio check')
        # Validate the exact peer and reference before hardware enumeration or
        # output creation. A configured key is not a session authentication.
        preflight, _ = passive_key_command(target_address)
        preflight.Clear()
    if tracking_only and (passive_key or radio_check):
        raise ValueError('Tracking-only cannot be combined with peer authentication or radio-check mode')
    ports = [p for p in list_ports.comports() if p.device == port_name]
    if len(ports) != 1 or (ports[0].vid, ports[0].pid) != (0xc0ff, 0xeeee):
        raise ValueError('Only the explicit ButteRFly USB identity is admitted; Nordic/Listener ports refused')
    output.mkdir(exist_ok=False)
    import csv, io, subprocess
    sid = list(csv.reader(io.StringIO(subprocess.check_output(
        ['whoami', '/user', '/fo', 'csv', '/nh'], text=True))))[0][1]
    subprocess.run(['icacls', str(output.resolve()), '/inheritance:r', '/grant:r',
                    '*'+sid+':(OI)(CI)F', 'SYSTEM:(OI)(CI)F'], check=True, stdout=subprocess.DEVNULL)
    meta = dict(startedAt=datetime.datetime.now().astimezone().isoformat(),
                productCommands=0, receiverCommands=[], messageCounts={}, ready=False,
                initialAdvertisingChannel=channel,
                targetAddress=sniff_target[::-1].hex() if sniff_target else None,
                passiveKeyRequested=passive_key, passiveKeyLoaded=False,
                trackingOnly=tracking_only, peerAuthenticationQualified=False,
                radioCheckOnly=radio_check,
                fullEncryptedOtaFollowingQualified=False,
                scope='Missing-handshake diagnostic only; host arrival timestamps are not exact RF/HCI alignment')
    codec, counts = Frames(), collections.Counter()
    raw_file = (output / 'receiver-private.bin').open('wb')
    # Live witness must include the latest complete RF line, not wait for 8KB.
    packet_file = (output / 'packets-private.jsonl').open('w', encoding='utf-8', buffering=1)
    save = lambda: (output / 'capture.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    context = contextlib.nullcontext(borrowed_port) if borrowed_port is not None else serial.Serial(port_name, baudrate=115200, timeout=.05, write_timeout=2)
    with context as port:
        def receive():
            data = port.read(port.in_waiting or 1)
            raw_file.write(data)
            msgs = codec.feed(data)
            for msg in msgs:
                domain = msg.WhichOneof('msg')
                kind = getattr(msg, domain).WhichOneof('msg') if domain else None
                counts[str(domain)+'.'+str(kind)] += 1
                if domain == 'generic' and kind == 'debug':
                    debug = bytes(msg.generic.debug.data).decode('ascii', errors='replace')
                    match = re.fullmatch(r'passive_crypto handshakes=(\d+) controls_ok=(\d+) controls_rejected=(\d+) max_us=(\d+)(?: callback_us=(\d+) queue_drops=(\d+) queue_peak=(\d+))?(?: hops=(\d+))?(?: usb_waits=(\d+) usb_drops=(\d+) usb_peak=(\d+))?', debug)
                    if match:
                        meta['passiveCryptoStats'] = dict(zip(
                            ('handshakes','controlsOk','controlsRejected','maxUs','callbackMaxUs','queueDrops','queuePeak','hops','usbWaits','usbDrops','usbPeak'),
                            (int(x) for x in match.groups() if x is not None)))
                    if debug.startswith('receiver_boot '): meta['receiverBoot'] = dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',debug))
                    if debug.startswith('initial_follow '): meta['initialFollowStats'] = dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',debug))
                    if debug.startswith('follow_loss '): meta['followLossStats'] = dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',debug))
                    if debug.startswith('rf_export '): meta['rfExportStats'] = dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',debug))
                    if debug.startswith('heap '): meta['heapStats'] = dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',debug))
                    if debug.startswith('usb_tx '): meta['usbTxStats'] = dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',debug))
                    if debug.startswith('rx_snapshot '): meta['rxSnapshotStats'] = dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',debug))
                    config = re.fullmatch(r'passive_config enabled=([01])(?: hopping=([01]))?', debug)
                    if config:
                        meta['passiveConfigEnabled'] = config.group(1)=='1'
                        if config.group(2) is not None: meta['passiveAdvertisingHopping'] = config.group(2)=='1'
                if domain == 'ble' and kind == 'raw_pdu':
                    p = msg.ble.raw_pdu
                    packet_file.write(json.dumps(dict(hostArrivalEpoch=time.time(),
                        deviceTimestampUs=p.timestamp, aa=f'{p.access_address:08x}',
                        direction=p.direction, channel=p.channel, rssi=p.rssi,
                        crcValid=p.crc_validity, pdu=p.pdu.hex(), crc=p.crc,
                        firmwareDecrypted=p.decrypted))+'\n')
            return msgs

        def exchange(msg, expect):
            port.write(wire(msg))
            domain = msg.WhichOneof('msg')
            meta['receiverCommands'].append(domain+'.'+getattr(msg, domain).WhichOneof('msg'))
            deadline = time.monotonic() + 3
            while time.monotonic() < deadline:
                for response in receive():
                    if expect(response):
                        return response
            raise TimeoutError('No explicit receiver response; not ready')

        def acknowledged(msg):
            response = exchange(msg, lambda x: x.WhichOneof('msg') == 'generic' and
                                x.generic.WhichOneof('msg') in ('cmd_result', 'result'))
            kind = response.generic.WhichOneof('msg')
            result = response.generic.cmd_result.result if kind == 'cmd_result' else response.generic.result
            if result != 0:
                raise ValueError('Receiver rejected passive command: '+str(result))

        try:
            query = command('discovery', 'info_query')
            query.discovery.info_query.proto_ver = 0x0100
            info = exchange(query, lambda x: x.WhichOneof('msg') == 'discovery' and
                            x.discovery.WhichOneof('msg') == 'info_resp').discovery.info_resp
            expected_version = (info.fw_version_major, info.fw_version_minor, info.fw_version_rev)
            assert info.type == 1 and expected_version in ((1,1,6),(1,1,106),(1,1,107),(1,1,108),(1,1,109),(1,1,110),(1,1,111),(1,1,112),(1,1,113),(1,1,114),(1,1,115),(1,1,116),(1,1,117),(1,1,118),(1,1,119),(1,1,120),(1,1,121),(1,1,122),(1,1,123),(1,1,124),(1,1,125),(1,1,126),(1,1,127))
            assert not passive_key or expected_version in ((1,1,106),(1,1,107),(1,1,108),(1,1,109),(1,1,110),(1,1,111),(1,1,112),(1,1,113),(1,1,114),(1,1,115),(1,1,116),(1,1,117),(1,1,118),(1,1,119),(1,1,120),(1,1,121),(1,1,122),(1,1,123),(1,1,124),(1,1,125),(1,1,126),(1,1,127))
            assert b'butterfly' in info.fw_url.lower()
            meta['firmware'] = '.'.join(map(str, expected_version))
            meta['deviceIdFingerprint'] = __import__('hashlib').sha256(info.devid).hexdigest()
            exchange(command('discovery','reset_query'), lambda x: x.WhichOneof('msg') == 'discovery' and
                     x.discovery.WhichOneof('msg') == 'ready_resp')
            if radio_check:
                sniff = command('ble','sniff_adv')
                sniff.ble.sniff_adv.channel = channel
                sniff.ble.sniff_adv.bd_address = bytes([255])*6
                sniff.ble.sniff_adv.use_extended_adv = False
            else:
                sniff = connection_sniff_command(channel, target_address)
            acknowledged(sniff)
            if passive_key or tracking_only:
                if tracking_only:
                    key_command, binding = tracking_only_command(fixed_advertising=fixed_advertising), None
                else:
                    key_command, binding = passive_key_command(target_address)
                if fixed_advertising:
                    assert expected_version >= (1,1,112), 'Fixed mode requires explicit receiver support'
                    key_command.ble.encryption.conn_handle=0xfffe
                acknowledged(key_command)
                key_command.Clear()
                if expected_version >= (1,1,108):
                    assert meta.get('passiveConfigEnabled') is True, 'Passive mode was not explicitly confirmed; no start or OTA'
                if expected_version >= (1,1,112):
                    assert meta['passiveAdvertisingHopping'] == (not fixed_advertising), 'Advertising mode not confirmed'
                meta['passiveKeyLoaded'] = passive_key
                meta['peerKeyBindingQualified'] = passive_key
                if binding is not None: meta['bondBindingSha256'] = binding
                if tracking_only: meta['configurationScope'] = 'wide passive RX with dummy non-peer key; no bond read or authentication claim'
            acknowledged(command('ble','start'))
            if not radio_check and fixed_advertising:
                # Firmware start() overwrites lastAdvertisingChannel with 37,
                # while leaving the initially requested RF channel unchanged.
                # stopConnection() then silently returns to 37 after the first
                # link. Reapply the existing passive configuration *after*
                # start, before declaring ready or allowing product actions.
                # SniffConnReq sets both current and remembered channel and
                # retains the loaded key. Never abort an already acquired link.
                assert not counts['ble.synchronized'], 'Link acquired during initial setup; refusing to reconfigure a live connection'
                acknowledged(connection_sniff_command(channel, target_address))
                meta['fixedChannelReappliedAfterStart'] = channel
                meta['fixedChannelReapplyReason'] = 'Receiver start resets remembered advertising channel to37; preserve explicit reconnect channel'
            meta['ready'] = True
            save()
            deadline = time.monotonic() + seconds
            while time.monotonic() < deadline and not (stop_event is not None and stop_event.is_set()):
                receive()
            meta['cancelRequested'] = bool(stop_event is not None and stop_event.is_set())
        except Exception as error:
            meta['error'] = type(error).__name__+': '+str(error)
            raise
        finally:
            try:
                acknowledged(command('ble','stop'))
                meta['stopAcknowledged'] = True
            except Exception as error:
                meta['stopAcknowledged'] = False
                meta['stopError'] = str(error)
            meta.update(messageCounts=dict(counts), framingDiscardedBytes=codec.discarded,
                        completedAt=datetime.datetime.now().astimezone().isoformat())
            raw_file.close()
            packet_file.close()
            save()
    return meta


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--seconds', type=int, default=30)
    parser.add_argument('--channel', type=int, choices=(37,38,39), default=37)
    parser.add_argument('--passive-key', action='store_true', help='Custom 1.1.106 only: validated bond retained in analyzer RAM; no active RF')
    parser.add_argument('--fixed-advertising', action='store_true', help='112+: stay on requested advertising channel, preserving passive control following')
    parser.add_argument('--radio-check', action='store_true', help='Passive advertisements without key or product operations')
    parser.add_argument('--target-address', help='Current verified Listener address; required for connection following')
    parser.add_argument('--tracking-only', action='store_true', help='115: enable wide passive RX without a peer key; no authentication qualification')
    args = parser.parse_args()
    if not args.port:
        self_check()
    else:
        assert args.output and 1 <= args.seconds <= 90
        if not args.radio_check:
            target_address_bytes(args.target_address)
        state=ROOT/'receiver-session-private/owner.json'
        owner=json.loads(state.read_text()) if state.exists() else {}
        if owner.get('running'):
            # Reuse the receiver owner. Closing standalone COM handles resets
            # this firmware; never silently fall back after an owner failure.
            from receiver_session import request
            assert args.port==owner['port'], 'Receiver owner port mismatch'
            assert owner.get('protocolVersion', 1) >= 3, 'Receiver owner must support explicit tracking-only semantics; no legacy fallback'
            if args.passive_key and target_address_bytes(args.target_address) == bytes.fromhex('6ab8af5b51f0'):
                assert owner.get('protocolVersion', 1) >= 4, 'Current-peer MIC binding requires receiver owner protocol4; no old-key fallback'
            result=request(dict(action='capture',output=str(args.output.resolve()),seconds=args.seconds,
                channel=args.channel,passiveKey=args.passive_key,radioCheck=args.radio_check,fixedAdvertising=args.fixed_advertising,targetAddress=args.target_address,trackingOnly=args.tracking_only))
            if not result.get('ok'):raise RuntimeError(result.get('error','Receiver owner failed'))
        else:
            capture(args.port, args.output, args.seconds, args.channel, args.passive_key, args.radio_check, args.fixed_advertising,target_address=args.target_address,tracking_only=args.tracking_only)
