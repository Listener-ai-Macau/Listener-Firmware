"""Actual ARM producer/export clock counterexample, with modeled END/IRQ inputs.

The virtual RX consumer is replaced by a timestamp witness. Actual linked
getter, packet constructor/header setter and Controller::addPacket are run.
This is not live RF calibration or proof of a throughput improvement.
"""
from pathlib import Path
import datetime,hashlib,json,sys
R=Path(__file__).resolve().parent;sys.path[:0]=[str(R),str(R/'arm-emulator-libs')]
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_THUMB,UC_MODE_MCLASS,UC_HOOK_CODE
from unicorn.arm_const import UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3,UC_ARM_REG_SP,UC_ARM_REG_LR,UC_ARM_REG_PC,UC_CPU_ARM_CORTEX_M4
from elftools.elf.elffile import ELFFile
from fresh_rf_gate import wire_crc
END=0x70000;CB=0x70010;OBJ=0x20032000;CON=0x20035000;VT=0x20035100;PKT=0x20036000;RAW=0x20037000;OUT=0x2003a000
RADIO=0x40001000;T4=0x4001b000

class Arm:
 def __init__(self,path):
  self.path=path;self.u=Uc(UC_ARCH_ARM,UC_MODE_THUMB|UC_MODE_MCLASS);self.members={};self.sizes={};self.writes=[];self.enqueued=[];self.full_rx_fixture=False;self.heap_slot=0;self.export_legacy=[];self.flow=[]
  self.u.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_M4)
  for b,n in [(0,0x100000),(0x20000000,0x40000),(0x40000000,0x200000),(0x50000000,0x10000),(0xe0000000,0x100000)]:self.u.mem_map(b,n)
  with path.open('rb') as f:
   e=ELFFile(f)
   for s in e.iter_sections():
    if s['sh_size'] and s['sh_flags']&2 and s['sh_type']!='SHT_NOBITS':self.u.mem_write(s['sh_addr'],s.data())
   self.syms={s.name:s['st_value'] for s in e.get_section_by_name('.symtab').iter_symbols()}
   for cu in e.get_dwarf_info().iter_CUs():
    for d in cu.iter_DIEs():
     n=d.attributes.get('DW_AT_name');n=n.value.decode() if n else ''
     if d.tag=='DW_TAG_typedef' and n=='receiver_export_frame':d=d.get_DIE_from_attribute('DW_AT_type')
     if n in ['Radio','Packet','BLEController','receiver_export_frame'] and 'DW_AT_byte_size' in d.attributes:
      self.members[n]={c.attributes['DW_AT_name'].value.decode():c.attributes['DW_AT_data_member_location'].value for c in d.iter_children() if c.tag=='DW_TAG_member' and 'DW_AT_data_member_location' in c.attributes}
      self.sizes[n]=d.attributes['DW_AT_byte_size'].value
  self.flow_symbols={next(v for n,v in self.syms.items() if text in n)&~1:text for text in ['13BLEController13onReceiveWide','advertisementPacketProcessing','advertisementSniffingProcessing','10Controller9addPacket']}
  self.callback=False;self.fixture_packet_allocation=False
  # Observe only the modeled API boundaries; do not split every Thumb IT block
  # into per-instruction hook exits when no instruction-level evidence is needed.
  points={CB,self.syms['malloc']&~1,self.syms['free']&~1,self.syms['receiver_export_enqueue']&~1,self.sym('10Controller9addPacket')&~1}|set(self.flow_symbols)
  for at in points:self.u.hook_add(UC_HOOK_CODE,self.hook,begin=at,end=at)
  # Unicorn's global MEM_WRITE callback changes Thumb IT execution in the saved
  # max-IRQ-age fragment (standalone no-op-hook counterexample is retained).
  # Keep MMIO state snapshots; do not use invasive write hooks as an oracle.
  self.call('_ZN5RadioC1Ev',[OBJ]);m=self.members['Radio']
  for n,v in dict(state=1,mode=0,phy=2,crc=0,crcSize=3,payloadLength=40,rssi=0,filterEnabled=0,matchingEnable=0).items():self.u.mem_write(OBJ+m[n],bytes([v]))
  self.u.mem_write(OBJ+m['header'],bytes([1,8,0]));self.u.mem_write(OBJ+m['preamble']+5,b'\x04')
  self.put(OBJ+m['controller'],CON);self.put(CON,VT)
  for i in range(7):self.put(VT+4*i,CB|1)
  self.ram=bytes(self.u.mem_read(0x20000000,0x40000));self.context=self.u.context_save()
 def sym(self,text):return next(v for n,v in self.syms.items() if text in n)
 def put(self,p,v):self.u.mem_write(p,int(v&0xffffffff).to_bytes(4,'little'))
 def get(self,p):return int.from_bytes(self.u.mem_read(p,4),'little')
 def hook(self,u,addr,size,user):
  if self.full_rx_fixture and addr in self.flow_symbols:self.flow.append(dict(function=self.flow_symbols[addr],r0=hex(u.reg_read(UC_ARM_REG_R0)),r1=hex(u.reg_read(UC_ARM_REG_R1)),r2=u.reg_read(UC_ARM_REG_R2),stack0=self.get(u.reg_read(UC_ARM_REG_SP)),stack1=self.get(u.reg_read(UC_ARM_REG_SP)+4)))
  if self.full_rx_fixture and addr==(self.syms['malloc']&~1):
   assert u.reg_read(UC_ARM_REG_R0)<320 and self.heap_slot<8
   ptr=0x20037000+self.heap_slot*512;self.heap_slot+=1
   u.reg_write(UC_ARM_REG_R0,ptr);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR));return
  if self.full_rx_fixture and addr==(self.syms['free']&~1):
   u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR));return
  if addr==(self.sym('10Controller9addPacket')&~1):
   pkt=u.reg_read(UC_ARM_REG_R1);self.export_legacy.append(self.get(pkt+self.members['Packet']['timestamp']))
  if self.fixture_packet_allocation and addr==(self.syms['malloc']&~1):
   assert u.reg_read(UC_ARM_REG_R0)<320
   u.reg_write(UC_ARM_REG_R0,0x20038000);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR));return
  if addr==CB:
   self.callback=True;u.emu_stop();return
  if addr==(self.syms['receiver_export_enqueue']&~1):
   p=u.reg_read(UC_ARM_REG_R0);m=self.members['receiver_export_frame']
   self.enqueued.append(dict(timestamp=self.get(p+m['timestamp']),relative=self.get(p+m['relative_timestamp']),
    pduSha256=hashlib.sha256(bytes(u.mem_read(p+m['pdu'],int.from_bytes(u.mem_read(p+m['length'],2),'little')))).hexdigest()))
   u.reg_write(UC_ARM_REG_R0,1);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
 def call(self,name,args=(),sp=0x2003d000,allow_callback=False):
  address=self.syms[name] if isinstance(name,str) else name
  for reg,v in zip([UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3],args):self.u.reg_write(reg,v)
  for i,v in enumerate(args[4:]):self.put(sp+4*i,v)
  self.u.reg_write(UC_ARM_REG_SP,sp);self.u.reg_write(UC_ARM_REG_LR,END|1)
  self.u.emu_start(address|1,END,count=200000)
  pc=self.u.reg_read(UC_ARM_REG_PC)
  assert pc==END or (allow_callback and pc==CB),(name,hex(pc),sorted([(v,n) for n,v in self.syms.items() if v<=pc],reverse=True)[:2])
  return self.u.reg_read(UC_ARM_REG_R0)
 def configure_mmio_canaries(self,phy):
  # Nonzero, fixed BLE-like register fixtures. This does not execute or certify
  # a live hardware configuration; it catches export code overwriting it.
  values={0x508:2,0x510:4 if phy==3 else 3,0x51c:0x89bed600,0x524:0x8e,
   0x530:1,0x534:0x103,0x53c:0x555555,0x554:37,0x514:0x108,0x518:0x2030028,
   0x504:OBJ+self.members['Radio']['rxBuffer'],0x200:1}
  for off,value in values.items():self.put(RADIO+off,value)
 def radio_configuration(self):
  return {hex(off):self.get(RADIO+off) for off in [0x508,0x510,0x51c,0x524,0x530,0x534,0x53c,0x554,0x514,0x518,0x504,0x200]}
 def run(self,raw,phy,delay,end,ppi=True):
  self.u.mem_write(0x20000000,self.ram);self.u.context_restore(self.context);self.u.ctl_remove_cache(0,0x100000)
  self.u.mem_write(RADIO,bytes(0x1000));self.u.mem_write(T4,bytes(0x1000))
  m=self.members['Radio'];self.u.mem_write(OBJ+m['phy'],bytes([phy]));self.u.mem_write(OBJ+m['payloadLength'],bytes([255 if phy==3 else 40]))
  self.u.mem_write(OBJ+m['rxBuffer'],raw);self.u.mem_write(self.sym('rxEndCaptureEnabledE'),bytes([int(ppi)]))
  self.put(RADIO+0x10c,1);self.put(RADIO+0x400,1);self.put(RADIO+0x40c,0)
  self.put(RADIO+0x100,1);self.put(RADIO+0x200,1);self.put(RADIO+0x550,3)
  self.configure_mmio_canaries(phy);radio_before=self.radio_configuration()
  self.put(T4+0x550,end);self.put(T4+0x554,end+delay)
  self.callback=False;self.writes=[];self.enqueued=[]
  self.call('RADIO_IRQHandler',allow_callback=True);assert self.callback
  callback_context=self.u.context_save();legacy=self.u.reg_read(UC_ARM_REG_R1)
  expected_legacy=(end+delay-(4+len(raw))*(4 if phy==3 else 8)-100)&0xffffffff
  assert legacy==expected_legacy
  hardware=(end-(len(raw)+4+3+(2 if phy==3 else 1))*(4 if phy==3 else 8))&0xffffffff
  getter=next((v for n,v in self.syms.items() if 'radioCurrentRxHardwareStart' in n),None)
  accepted=False;export=legacy
  if getter:
   self.put(OUT,0xdeadbeef);accepted=bool(self.call(getter,[legacy,OUT],sp=0x2003b000));export=self.get(OUT) if accepted else legacy
   assert not self.call(getter,[(legacy+1)&0xffffffff,OUT],sp=0x2003b000)
   assert not self.call(getter,[legacy,0],sp=0x2003b000)
  self.u.context_restore(callback_context);self.u.reg_write(UC_ARM_REG_PC,self.u.reg_read(UC_ARM_REG_LR))
  self.u.emu_start(self.u.reg_read(UC_ARM_REG_PC)|1,END,count=200000);assert self.u.reg_read(UC_ARM_REG_PC)==END
  if getter:assert not self.call(getter,[legacy,OUT],sp=0x2003b000)
  self.u.mem_write(RAW,raw)
  ctor=next(v for n,v in self.syms.items() if n.startswith('_ZN9BLEPacketC1'))
  self.fixture_packet_allocation=True
  self.call(ctor,[PKT,0x8e89bed6,RAW,len(raw),legacy,23,0,37,40,0,0])
  self.fixture_packet_allocation=False
  old_link=self.call(self.sym('6Packet12getTimestampEv'),[PKT])
  if accepted:self.call(self.sym('setExportTimestamp'),[PKT,export])
  assert self.call(self.sym('6Packet12getTimestampEv'),[PKT])==old_link==legacy
  self.call(self.sym('10Controller9addPacket'),[CON,PKT]);assert len(self.enqueued)==1
  assert self.enqueued[0]['pduSha256']==hashlib.sha256(raw).hexdigest()
  assert self.enqueued[0]['timestamp']==export
  assert self.radio_configuration()==radio_before
  return dict(phy='2M' if phy==3 else '1M',pduBytes=len(raw),modeledIrqDelayUs=delay,modeledEndUs=end,hardwareEndAvailable=ppi,
   legacyControllerTimestamp=legacy,exportTimestamp=export,hardwareDerivedExpected=hardware,hardwareStampAdmitted=accepted,
   exportMatchesHardware=export==hardware,controllerClockUnchanged=True,rawBytesUnchanged=True,radioConfiguration=self.radio_configuration())

 def full_receive(self,raw,delay):
  # Full-path cases use a fresh Arm instance; do not restore a CPU checkpoint
  # created for the separate virtual-consumer clock fixtures.
  self.u.mem_write(RADIO,bytes(0x1000));self.u.mem_write(T4,bytes(0x1000))
  self.u.mem_write(CON,bytes(self.sizes['BLEController']))
  core=0x20034800;tm=0x20034c00;seq=0x20034a00
  self.put(self.syms['_ZN4Core8instanceE'],core);self.put(core+16,tm);self.put(core+20,seq);self.put(core+24,OBJ)
  self.call(self.sym('13BLEControllerC1'),[CON,OBJ])
  bm=self.members['BLEController'];rm=self.members['Radio']
  fixture_radio={n:bytes(self.u.mem_read(OBJ+rm[n],1)).hex() for n in ['crc','mode','state','phy']}
  assert fixture_radio['crc']=='00',fixture_radio
  self.put(CON+bm['controllerState'],1);self.put(CON+bm['accessAddress'],0x8e89bed6);self.put(CON+bm['channel'],37)
  self.u.mem_write(CON+bm['follow'],b'\x00')
  self.u.mem_write(OBJ+rm['rxBuffer'],raw);self.u.mem_write(self.sym('rxEndCaptureEnabledE'),b'\x01')
  self.put(RADIO+0x10c,1);self.put(RADIO+0x400,1);self.put(RADIO+0x40c,0)
  self.put(RADIO+0x100,1);self.put(RADIO+0x200,1);self.put(RADIO+0x550,3)
  self.configure_mmio_canaries(2);radio_before=self.radio_configuration()
  self.put(T4+0x550,1000000);self.put(T4+0x554,1000000+delay)
  self.full_rx_fixture=True;self.heap_slot=0;self.enqueued=[];self.export_legacy=[];self.writes=[];self.flow=[]
  self.call('RADIO_IRQHandler');self.full_rx_fixture=False
  assert len(self.enqueued)==len(self.export_legacy)==1,(self.flow,self.enqueued,self.export_legacy,self.heap_slot)
  assert set(self.flow_symbols.values())<={x['function'] for x in self.flow}
  assert self.enqueued[0]['pduSha256']==hashlib.sha256(raw).hexdigest()
  assert self.radio_configuration()==radio_before
  return dict(modeledIrqDelayUs=delay,exportTimestamp=self.enqueued[0]['timestamp'],legacyControllerTimestamp=self.export_legacy[0],
    radioConfiguration=self.radio_configuration(),rawBytesUnchanged=True,fixtureHeapSlots=self.heap_slot,
    observedProductionFlow=[x['function'] for x in self.flow])

rows=[json.loads(x) for x in (R/'passive-current-20261019-163126/rf-private/packets-private.jsonl').read_text().splitlines()]
vectors=[bytes.fromhex(next(x['pdu'] for x in rows if x['aa']=='8e89bed6' and len(bytes.fromhex(x['pdu']))==14)),
 bytes.fromhex(next(x['pdu'] for x in rows if x['aa']=='52b3721e' and len(bytes.fromhex(x['pdu']))==2)),
 bytes.fromhex(next(x['pdu'] for x in rows if x['aa']=='52b3721e' and len(bytes.fromhex(x['pdu']))==257))]
cases=[(raw,phy,delay,1000000,True) for raw,phy in zip(vectors,[2,3,3]) for delay in [0,83,115]]
cases += [(vectors[2],3,83,30,True),(vectors[0],2,83,1000000,False)]
before=Arm(R/'source-rxdiag128/build/nrf52840_xxaa.out');after=Arm(R/'source-rxtiming129/build/nrf52840_xxaa.out')
assert all(before.sizes[n]==after.sizes[n] for n in ['Packet','BLEController','receiver_export_frame'])
results=[]
for args in cases:
 b=before.run(*args);a=after.run(*args)
 assert b['legacyControllerTimestamp']==a['legacyControllerTimestamp'] and b['radioConfiguration']==a['radioConfiguration']
 assert a['hardwareStampAdmitted']==args[4]
 assert (a['exportMatchesHardware'] if args[4] else a['exportTimestamp']==b['exportTimestamp'])
 results.append(dict(before=b,after=a))
assert not all(x['before']['exportMatchesHardware'] for x in results)
for i in range(0,9,3):assert len({x['after']['exportTimestamp'] for x in results[i:i+3]})==1 and len({x['before']['exportTimestamp'] for x in results[i:i+3]})==3
full=[]
for delay in [0,83,115]:
 full_before=Arm(before.path);full_after=Arm(after.path)
 b=full_before.full_receive(vectors[0],delay);a=full_after.full_receive(vectors[0],delay)
 assert b['legacyControllerTimestamp']==a['legacyControllerTimestamp'] and b['radioConfiguration']==a['radioConfiguration']
 assert a['exportTimestamp']==1000000-(len(vectors[0])+8)*8
 full.append(dict(before=b,after=a))
report=dict(at=datetime.datetime.now().astimezone().isoformat(),beforeElfSha256=hashlib.sha256(before.path.read_bytes()).hexdigest(),
 afterElfSha256=hashlib.sha256(after.path.read_bytes()).hexdigest(),cases=results,caseCount=len(results),
 full1mReceivePathCases=full,packetControllerAndExportLayoutSizesUnchanged=True,executedProductionFunctions=['RADIO_IRQHandler','BLEController onReceiveWide/advertisement processing','radioCurrentRxHardwareStart','BLEPacket constructor','Packet getTimestamp/setExportTimestamp','Controller addPacket to export admission'],
 observerLimitation='Global MEM_WRITE hooks change the retained Thumb IT fragment; excluded from this proof. Nonzero fixed MMIO configuration snapshots match before/after, not an assertion that every write was traced.',
 scope='MMIO END/IRQ times and initial configuration are modeled.11 clock cases use virtual-consumer witness;3 full1M cases execute real BLE receive/processing/export functions with isolated allocator storage. Allocator, live RF and absolute radio pipeline offset are not under test. Export admission is observed before existing queue. No analog calibration, live follow acceptance, MCU instruction time or speed gain inferred. Relative timestamps retain legacy clock.')
(R/'rx-export-timestamp129-arm-before-after.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(caseCount=len(results),hardwareCases=sum(x['after']['hardwareStampAdmitted'] for x in results),fullReceiveCases=len(full),controllerClocksAndRadioConfigurationUnchanged=True,hardwareOperations=0)))
