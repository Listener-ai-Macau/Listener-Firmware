"""One bounded natural-use audio collection and immediate idle-only device read.

Never starts recording, OTA, reconnection, pairing, reboot, or Type shutdown.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,sys,time,uuid,psutil

p=argparse.ArgumentParser();p.add_argument('--seconds',type=int,default=30);p.add_argument('--daily54-fw31',action='store_true');a=p.parse_args()
assert 10<=a.seconds<=60
r=Path(__file__).resolve().parent
fw=Path('C:/Users/Billy/Desktop/Denzic/Listener/Listener-Firmware')
app=Path('C:/Program Files/Listener Type/listener-type.exe')
expected_app_sha='bb2bffe96f6b17ff847685d71be681e54fa0b03db1e564c41477c01f114fc593'
target='F0:51:5B:AF:B8:6A'
if a.daily54_fw31:
 baseline=json.loads((r/'daily-baseline-type54-fw31.json').read_text())
 expected_app_sha=baseline['dailyTypeExeSha256']
 assert expected_app_sha=='59ca7597c20c5627c173bd8270a4934399eea3fda3d3d19b7dd8e809150a55a2'
 assert baseline['firmwareSourceCommit']=='b8311a73fcf4e37c78d6d83273e96f9b34eb605a'
 target='F8:34:69:CA:5C:53';assert baseline['peer']==target.replace(':','')
assert hashlib.sha256(app.read_bytes()).hexdigest()==expected_app_sha
identity=lambda:sorted((x.pid,x.create_time()) for x in psutil.process_iter(['name']) if (x.info['name'] or '').lower()=='listener-type.exe')
before=identity();assert len(before)==2
cmd=[sys.executable,str(r/'passive_current_round.py'),'--seconds',str(a.seconds),'--channel','37','--fixed-advertising','--usb-events']
if a.daily54_fw31:
 # This peer's key remains unverified. Collect raw RX and HCI without loading
 # another board's key or requiring artificial recording/reconnection.
 cmd+=['--target-address',target.replace(':',''),'--tracking-only']
run=subprocess.run(cmd,capture_output=True,text=True,timeout=a.seconds+45,creationflags=subprocess.CREATE_NO_WINDOW)
records=[]
for line in run.stdout.splitlines():
 try:records.append(json.loads(line))
 except ValueError:pass
out=Path(next(x['output'] for x in records if 'output' in x)).resolve();assert out.is_relative_to(r)
(out/'natural-audio-collector.log').write_text(run.stdout+run.stderr)
report=dict(at=datetime.datetime.now().astimezone().isoformat(),collectorExit=run.returncode,otaRequested=False,recordingRequested=False,powerOrConnectionChanges=0,typeQuitRequested=False,firmwareExportAttempted=False)
report.update(targetAddress=target,expectedTypeExeSha256=expected_app_sha,daily54Fw31=a.daily54_fw31)
def execute(cmd,name,timeout):
 with (out/name).open('wb') as f:return subprocess.run([str(x) for x in cmd],stdout=f,stderr=f,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW).returncode
try:
 assert run.returncode==0 and identity()==before
 token=str(uuid.uuid4())
 assert execute([app,'--diagnostic-dictation-snapshot',token],'natural-idle.log',10)==0
 path=Path('C:/Users/Billy/AppData/Local/Listener Type/Logs/diagnostic-dictation-snapshot')/(token+'.json');deadline=time.monotonic()+5
 while not path.exists() and time.monotonic()<deadline:time.sleep(.05)
 snapshot=json.loads(path.read_text(encoding='utf-8-sig'))
 assert snapshot['servicePid'] in [x[0] for x in before]
 (out/'natural-idle.json').write_text(json.dumps(snapshot,indent=2))
 if snapshot['snapshot']['phase']=='idle' and not snapshot['snapshot']['pendingStop']:
  report['firmwareExportAttempted']=True
  report['firmwareExportExit']=execute([sys.executable,fw/'tools/export_ble_diag_log.py','--address',target,'--count','256','--scan-timeout','.2','--notify-timeout','2','--output',out/'firmware-natural-audio.jsonl'],'firmware-natural-audio.log',18)
  if report['firmwareExportExit']==0:
   report['firmwareDecodeExit']=execute([sys.executable,fw/'tools/decode_diag_log.py','--input',out/'firmware-natural-audio.jsonl','--header',fw/'components/diag_log/include/diag_log_events.h','--output',out/'firmware-natural-audio-decoded.json'],'firmware-decode.log',10)
 else:report['firmwareExportSkipped']='Type was recording/finishing; user activity preserved'
 if (out/'hci-private.pcapng').exists():
  if a.daily54_fw31:
   from find_vka_hci_streams import discover
   streams=discover(out/'hci-private.pcapng');combined=[];exits=[]
   for index,stream in enumerate(streams):
    dest=out/f'audio-hci-stream-{index}.json'
    code=execute([sys.executable,r/'analyze_audio_hci.py','--pcap',out/'hci-private.pcapng','--output',dest,'--connection-handle',stream['connectionHandle'],'--attribute-handle',stream['attributeHandle'],'--peer','unbound_until_explicit_peer_session_join'],f'audio-stream-{index}.log',45)
    exits.append(code)
    if code==0:
     combined.extend([dict(s,connectionHandle=stream['connectionHandle'],attributeHandle=stream['attributeHandle']) for s in json.loads(dest.read_text())['sessions']])
   (out/'actual-audio-hci-accounting.json').write_text(json.dumps(dict(sessions=combined,discoveredStreams=streams,targetPeerLabel='unbound_until_explicit_peer_session_join'),indent=2))
   report['hciAudioExit']=max(exits,default=0)
   report['audioObservation']='VKA1 streams found; explicit device session join required' if streams else 'No VKA1 audio in this bounded interval; this is not an audio pass'
  else:
   report['hciAudioExit']=execute([sys.executable,r/'analyze_audio_hci.py','--pcap',out/'hci-private.pcapng','--output',out/'actual-audio-hci-accounting.json','--connection-handle','0x0800','--attribute-handle','0x0003','--peer',target],'audio-accounting.log',45)
 if (out/'firmware-natural-audio-decoded.json').exists() and (out/'actual-audio-hci-accounting.json').exists():
  device=json.loads((out/'firmware-natural-audio-decoded.json').read_text())
  hci=json.loads((out/'actual-audio-hci-accounting.json').read_text())
  stops={e['args_named']['session_id']:e for e in device['events'] if e['event']['name']=='audio_session' and e['args_named'].get('type')==2}
  report['matchedAudioSessions']=[]
  for s in hci['sessions']:
   e=stops.get(s['sessionId'])
   matches=sum(x['sessionId']==s['sessionId'] for x in hci['sessions'])
   if e is not None and matches==1:report['matchedAudioSessions'].append(dict(sessionId=s['sessionId'],targetPeer=target,connectionHandle=s.get('connectionHandle','0x0800'),hciHasStartStop=s['hasStart'] and s['hasStop'],hciCompleteAudioChunks=s['completeAudioChunks'],deviceCaptureFrames=e['args_named']['frame_count'],hciDeclaredPcmMs=s['declaredCompletePcmMs'],hciMissingSequences=s['missingWithinObservedSequence'],hciIncompleteChunks=s['incompleteChunkSequences'],hciMaximumFragmentGapMs=s['uniqueFragmentArrivalGapMs']['max']))
  report['ambiguousSessionIds']=sorted({s['sessionId'] for s in hci['sessions'] if sum(x['sessionId']==s['sessionId'] for x in hci['sessions'])>1})
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
 report['typeUnchanged']=before==identity();report['completedAt']=datetime.datetime.now().astimezone().isoformat()
 report['scope']='Actual natural audio at Windows HCI joined by sessionID to immediate device log read. RF is collected in the same interval but requires independent authentication/coverage; no claim of RF airtime or sustainable peak rate from audio arrival spacing.'
 (out/'natural-audio-joined.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(output=str(out),**report)))
