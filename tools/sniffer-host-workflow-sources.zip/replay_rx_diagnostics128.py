"""Exercise actual ARM receive counters, keeping bad CRC separate from RF proof."""
from pathlib import Path
import contextlib, datetime, hashlib, io, json, runpy, sys
R=Path(__file__).resolve().parent
elf=R/'source-rxdiag128/build/nrf52840_xxaa.out'
sys.argv=[str(R/'replay_radio_dma_snapshot.py'),'--elf',str(elf),'--output',str(R/'rxdiag128-dma-snapshot.json'),'--expect-fixed']
with contextlib.redirect_stdout(io.StringIO()):
    g=runpy.run_path(str(R/'replay_radio_dma_snapshot.py'))
u=g['u'];put=g['put32'];get=g['get32'];members=g['members'];obj=g['OBJECT'];radio=g['radio'];timer=g['timer4']
fields=['rxCrcGood','rxCrcBad','rxAdvGood','rxAdvBad','rxConnectGood','rxConnectBad']
addresses={f:next(v for n,v in g['symbols'].items() if n.endswith(f+'E')) for f in fields}
reset=next(n for n in g['symbols'] if 'resetRadioRxSnapshotStats' in n)
counter=lambda:{f:get(v) for f,v in addresses.items()}
cases=[]
for name,row,valid,ch in [('valid_connect',g['b'],True,37),('bad_crc_connect_header',g['b'],False,37),
    ('valid_directed_adv',g['a'],True,38),('bad_crc_adv',g['a'],False,38),('not_advertising_channel',g['b'],True,10)]:
    u.mem_write(0x20000000,g['baseline_ram']);u.context_restore(g['context'])
    u.mem_write(radio,bytes(0x1000));u.mem_write(timer,bytes(0x1000))
    u.mem_write(obj+members['whiteningDataIv'],bytes([ch]))
    raw=bytes.fromhex(row['pdu']);u.mem_write(g['rx'],raw)
    put(radio+0x10c,1);put(radio+0x400,int(valid));put(radio+0x40c,g['reverse_bytes'](row['crc']))
    put(timer+0x554,1000000)
    put(radio+0x100,1);put(radio+0x200,1);put(radio+0x550,3)
    g['call'](reset)
    observed=[]
    def hook(uc,addr,size,user):
        if addr==g['CALLBACK']:
            observed.append(uc.reg_read(g['UC_ARM_REG_R2']))
            uc.reg_write(g['UC_ARM_REG_PC'],uc.reg_read(g['UC_ARM_REG_LR']))
    h=u.hook_add(g['UC_HOOK_CODE'],hook);u.ctl_remove_cache(0,0x100000)
    g['call']('RADIO_IRQHandler');u.hook_del(h);u.ctl_remove_cache(0,0x100000)
    result=counter();assert len(observed)==1
    assert result['rxCrcGood']==int(valid) and result['rxCrcBad']==int(not valid)
    assert result['rxAdvGood']==int(valid and ch>=37) and result['rxAdvBad']==int(not valid and ch>=37)
    assert result['rxConnectGood']==int(valid and ch>=37 and len(raw)==36)
    assert result['rxConnectBad']==int(not valid and ch>=37 and len(raw)==36)
    g['call'](reset);assert not any(counter().values())
    cases.append(dict(name=name,actualCounters=result,resetClearsAll=True))
report=dict(at=datetime.datetime.now().astimezone().isoformat(),elfSha256=hashlib.sha256(elf.read_bytes()).hexdigest(),
    actualArmReceiveFunction='RADIO_IRQHandler',cases=cases,hardwareOperations=0,firmwareUploaded=False,
    scope='Runs linked ARM receive code with saved valid RF vectors; bad-CRC status is an explicitly modeled hardware input. The consumer is replaced with a length witness. No analog reception quality, on-device timing, new RF capture or throughput gain is asserted.')
(R/'rxdiag128-arm-counters.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
