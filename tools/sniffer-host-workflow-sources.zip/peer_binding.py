"""Explicit per-peer local proof. Never substitute another board's key."""
from pathlib import Path
import hashlib,json
R=Path(__file__).parent
NEW='cdb2f668b535'
def load(target):
 normalized=target.replace(':','').lower()
 if normalized==NEW:
  proof=json.loads((R/'peer-cdb2-mic-proof.json').read_text());refpath=R/proof['referencePath']
  assert refpath.resolve().is_relative_to(R.resolve())
  for source,digest in proof['sourcePacketSha256'].items():
   path=R/source;assert path.resolve().is_relative_to(R.resolve()) and hashlib.sha256(path.read_bytes()).hexdigest()==digest
  assert proof['totalMicVerified']>=8 and proof['rejectedRepresentationMicVerified']==[0]
  assert any(e['nonemptyUnique']>=8 and e['directions']==[0,1] for e in proof['epochs'])
 elif normalized=='f0515bafb86a':
  proof=json.loads((R/'current-bond-mic-proof.json').read_text());refpath=R/'current-peer-bond-private/verified-current-bond.json'
  assert proof['totalMicVerified']>=4 and sum(e['verifiedFrames']>=2 for e in proof['epochs'])>=2
 else:
  assert len(normalized)==12 and all(c in '0123456789abcdef' for c in normalized)
  proof=json.loads((R/('peer-'+normalized+'-mic-proof.json')).read_text());refpath=R/proof['referencePath']
  assert refpath.resolve().is_relative_to(R.resolve())
  for source,digest in proof['sourcePacketSha256'].items():
   path=R/source;assert path.resolve().is_relative_to(R.resolve()) and hashlib.sha256(path.read_bytes()).hexdigest()==digest
  assert proof['totalMicVerified']>=8 and proof['rejectedRepresentationMicVerified']==[0]
  assert any(e['nonemptyUnique']>=8 and e['directions']==[0,1] for e in proof['epochs'])
 raw=refpath.read_bytes();assert hashlib.sha256(raw).hexdigest()==proof['privateReferenceSha256'];ref=json.loads(raw)
 assert ref['listenerAddress']==proof['currentPeer'] and ref['listenerAddress'].replace(':','').lower()==normalized
 assert ref['peerAddress']==proof['localAdapter']=='68:34:21:92:02:24'
 assert hashlib.sha256(bytes.fromhex(ref['randHex']+ref['edivHex'])).hexdigest() in proof['lookupFingerprints']
 return ref,proof

def for_capture(path):
 meta=json.loads((Path(path).parent/'capture.json').read_text());target=meta['targetAddress']
 return load(target)
