"""Execute installed receiver packet parsing/filtering with saved RF vectors.

The F8 substitutions are synthetic address-only counterexamples, not RF captures.
No radio, Type, pairings, payload output, or keys are accessed.
"""
from pathlib import Path
import datetime, hashlib, json, sys
R = Path(__file__).resolve().parent
sys.path[:0] = [str(R), str(R/'arm-emulator-libs')]
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS
from unicorn.arm_const import UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_SP, UC_ARM_REG_LR, UC_ARM_REG_PC
from elftools.elf.elffile import ELFFile
from fresh_rf_gate import wire_crc

elf = R/'source/build/nrf52840_xxaa.out'
u = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
u.mem_map(0, 0x100000); u.mem_map(0x20000000, 0x40000)
with elf.open('rb') as f:
    e = ELFFile(f)
    for sec in e.iter_sections():
        if sec['sh_size'] and sec['sh_flags'] & 2 and sec['sh_type'] != 'SHT_NOBITS':
            u.mem_write(sec['sh_addr'], sec.data())
    symbols = {s.name: s['st_value'] for s in e.get_section_by_name('.symtab').iter_symbols()}
    packet_members = None
    for cu in e.get_dwarf_info().iter_CUs():
        for d in cu.iter_DIEs():
            if d.tag == 'DW_TAG_class_type' and d.attributes.get('DW_AT_name') and d.attributes['DW_AT_name'].value == b'Packet' and 'DW_AT_byte_size' in d.attributes:
                packet_members = {c.attributes['DW_AT_name'].value.decode(): c.attributes['DW_AT_data_member_location'].value for c in d.iter_children() if c.tag == 'DW_TAG_member' and 'DW_AT_data_member_location' in c.attributes}
                break
        if packet_members: break
assert packet_members
OBJ, RAW, END = 0x20032000, 0x20033000, 0x70000
u.mem_write(OBJ+packet_members['packetPointer'], RAW.to_bytes(4, 'little'))

def call(fragment, args):
    name = next(n for n in symbols if fragment in n)
    for reg, value in zip((UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3), args): u.reg_write(reg, value)
    u.reg_write(UC_ARM_REG_SP, 0x2003d000); u.reg_write(UC_ARM_REG_LR, END | 1)
    u.emu_start(symbols[name] | 1, END, count=10000)
    assert u.reg_read(UC_ARM_REG_PC) == END
    return u.reg_read(UC_ARM_REG_R0)

def accepted(pdu, address):
    u.mem_write(RAW, bytes.fromhex('d6be898e')+pdu+bytes(3))
    padded = address+bytes(2)  # actual ARM ABI: six-byte BLEAddress by value
    return call('checkAdvertiserAddress', (OBJ, int.from_bytes(padded[:4], 'little'), int.from_bytes(padded[4:], 'little')))

sources = ['passive-current-20261019-130914', 'passive-current-20261019-163126', 'passive-current-20261019-163459', 'passive-current-20261019-164650']
digests = {}; cases = []; count = 0
f8 = bytes.fromhex('f83469ca5c53')
for source in sources:
    path = R/source/'rf-private/packets-private.jsonl'
    digests[str(path.relative_to(R))] = hashlib.sha256(path.read_bytes()).hexdigest()
    for line in path.read_text().splitlines():
        row = json.loads(line); pdu = bytes.fromhex(row['pdu'])
        if row['aa'] != '8e89bed6' or len(pdu) != 36 or pdu[0] & 15 != 5: continue
        assert wire_crc(pdu, 0x555555) == row['crc']
        peer = pdu[8:14][::-1]
        assert accepted(pdu, peer) == 1
        assert call('extractAdvertisementType', (OBJ,)) == 5
        assert accepted(pdu, bytes([peer[0] ^ 1])+peer[1:]) == 0
        variant = bytearray(pdu); variant[8:14] = f8[::-1]
        assert accepted(bytes(variant), f8) == 1
        assert call('extractAdvertisementType', (OBJ,)) == 5
        assert accepted(bytes(variant), bytes.fromhex('cdb2f668b535')) == 0
        assert accepted(bytes(variant), bytes([255])*6) == 1
        count += 1
    cases.append({'capture': source, 'cumulativeRealConnectVectors': count})
assert count >= 4
out = dict(at=datetime.datetime.now().astimezone().isoformat(), elfSha256=hashlib.sha256(elf.read_bytes()).hexdigest(),
    sourcePacketSha256=digests, actualArmFunctions=['BLEPacket::checkAdvertiserAddress', 'BLEPacket::extractAdvertisementType', 'BLEPacket::isAdvertisement'],
    realConnectVectors=count, realAddressPass=count, wrongPeerRejected=count, f8SyntheticAddressPass=count, oldPeerRejectedForF8=count,
    wildcardPass=count, hardwareOperations=0, firmwareWrites=0, cases=cases,
    scope='Executes actual compiled ARM methods. F8 address substitution tests byte order and type filtering only. It does not reproduce analog RX, CRC failures, interrupt timing, live CONNECT coverage, or speed. No receiver/product change is justified solely by this exclusion.')
(R/'f834-filter-arm-exclusion.json').write_text(json.dumps(out, indent=2))
print(json.dumps({k:out[k] for k in ('realConnectVectors','f8SyntheticAddressPass','oldPeerRejectedForF8','hardwareOperations')}))
