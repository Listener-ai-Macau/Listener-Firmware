"""Bind only the exact paired peer's registry LTK to observed CRC/MIC RF; no plaintext output."""
from pathlib import Path
import argparse,collections,datetime,hashlib,json
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes
from cryptography.hazmat.primitives.ciphers.aead import AESCCM
from fresh_rf_gate import wire_crc
R=Path(__file__).resolve().parent
P=R/'peer-f834-20261019-private'
secret=json.loads((P/'registry-bond.json').read_text())
assert secret['listenerAddress']=='F8:34:69:CA:5C:53' and secret['localAdapter']=='68:34:21:92:02:24'
parser=argparse.ArgumentParser();parser.add_argument('--capture',type=Path,required=True);args=parser.parse_args()
source=args.capture.resolve()/'packets-private.jsonl'
assert source.is_relative_to(R.resolve())
meta=json.loads((source.parent/'capture.json').read_text());assert meta['targetAddress']=='f83469ca5c53' and meta['ready']
registry_meta=json.loads((R/'peer-f834-backup-metadata.json').read_text());assert hashlib.sha256((P/'registry-bond.json').read_bytes()).hexdigest()==registry_meta['privateReferenceSha256']
groups=collections.defaultdict(list);seeds={}
for line in source.read_text().splitlines():
 row=json.loads(line);raw=bytes.fromhex(row['pdu'])
 if len(raw)!=raw[1]+2 or not row['crcValid']:continue
 if row['aa']=='8e89bed6':
  if len(raw)==36 and raw[0]&15==5 and raw[8:14]==bytes.fromhex('535cca6934f8') and wire_crc(raw,0x555555)==row['crc']:
   seeds[raw[14:18][::-1].hex()]=int.from_bytes(raw[18:21],'big')
 elif row['aa'] in seeds and wire_crc(raw,seeds[row['aa']])==row['crc']:groups[row['aa']].append(row)
configs=[]
for order,key in [('raw',bytes.fromhex(secret['keyRaw'])),('reversed',bytes.fromhex(secret['keyRaw'])[::-1])]:
 epochs=[]
 for aa,rows in groups.items():
  req=iv=ccm=None;counters=[0,0];seen=set();count=0;lookup=None;request_hex=None
  for row in rows:
   raw=bytes.fromhex(row['pdu']);payload=raw[2:];llid=raw[0]&3
   if llid==3 and len(payload)==23 and payload[0]==3:req=payload;request_hex=payload.hex();lookup=hashlib.sha256(payload[1:11]).hexdigest();continue
   if llid==3 and len(payload)==13 and payload[0]==4 and req is not None and ccm is None:
    aes=Cipher(algorithms.AES(key),modes.ECB()).encryptor();ccm=AESCCM(aes.update((req[11:19]+payload[1:9])[::-1])+aes.finalize(),tag_length=4);iv=req[19:23]+payload[9:13];continue
   if ccm is None or len(payload)<5:continue
   found=False
   for d in [0,1]:
    for n in range(max(0,counters[d]-1),counters[d]+65):
     nonce=bytearray(n.to_bytes(5,'little')+iv);nonce[4]=(nonce[4]&127)|(d<<7)
     try:plain=ccm.decrypt(bytes(nonce),payload,bytes([raw[0]&0xe3]))
     except InvalidTag:continue
     counters[d]=max(counters[d],n+1);count+=1
     if plain:seen.add((d,n))
     found=True;break
    if found:break
  epochs.append({'aa':aa,'verifiedFrames':count,'nonemptyUnique':len(seen),'directions':sorted({d for d,n in seen}),'lookupFingerprints':[lookup] if lookup else [],'_request':request_hex})
 configs.append({'order':order,'epochs':epochs,'total':sum(e['verifiedFrames'] for e in epochs)})
winning=[c for c in configs if any(e['verifiedFrames']>=8 and e['nonemptyUnique']>=8 and e['directions']==[0,1] for e in c['epochs'])]
attempt=json.loads(json.dumps(configs))
for config in attempt:
 for epoch in config['epochs']:epoch.pop('_request',None)
(R/'peer-f834-binding-attempt.json').write_text(json.dumps({'source':str(source),'keyRepresentations':attempt,'qualified':len(winning)==1,'keyPrinted':False},indent=2))
assert len(winning)==1, 'Exact peer key did not uniquely authenticate eight distinct nonempty packets in both directions'
win=winning[0];key=bytes.fromhex(secret['keyRaw']);key=key if win['order']=='raw' else key[::-1]
request=bytes.fromhex(next(e['_request'] for e in win['epochs'] if e['verifiedFrames']>=8))
for c in configs:
 for e in c['epochs']:e.pop('_request',None)
ref={'listenerAddress':secret['listenerAddress'],'peerAddress':secret['localAdapter'],'keyBigEndian':'0x'+key.hex(),'randHex':request[1:9].hex(),'edivHex':request[9:11].hex()}
refpath=P/'verified-bond.json';refpath.write_text(json.dumps(ref,indent=2))
proof={'at':datetime.datetime.now().astimezone().isoformat(),'currentPeer':ref['listenerAddress'],'localAdapter':ref['peerAddress'],'privateReferenceSha256':hashlib.sha256(refpath.read_bytes()).hexdigest(),'referencePath':str(refpath.relative_to(R)),'sourcePacketSha256':{str(source.relative_to(R)):hashlib.sha256(source.read_bytes()).hexdigest()},'lookupFingerprints':sorted({x for e in win['epochs'] for x in e['lookupFingerprints']}),'epochs':win['epochs'],'totalMicVerified':win['total'],'rejectedRepresentationMicVerified':[c['total'] for c in configs if c is not win],'rawCrcChecked':True,'keyPrinted':False,'fullOtaCoverageQualified':False,'policy':'Exact Windows paired endpoint/own leaf registry backup, unique key representation, >=8 distinct nonempty MIC packets in both directions of an observed CRC-validated peer CONNECT. Separate fresh five-second RF admission still required for measurement.'}
(R/'peer-f83469ca5c53-mic-proof.json').write_text(json.dumps(proof,indent=2))
print(json.dumps({k:proof[k] for k in ['currentPeer','totalMicVerified','epochs','rejectedRepresentationMicVerified','fullOtaCoverageQualified']}))
