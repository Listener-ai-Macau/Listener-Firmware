"""Partition an actually byte-complete, authenticated2M image RF interval.

No inferred frames, controller attribution, raw payloads, keys or audio output.
Timestamp uncertainty and unobserved ACKs remain explicit limitations.
"""
from pathlib import Path
import argparse, collections, datetime, hashlib, json, statistics
from fresh_rf_gate import wire_crc

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--capture', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
root = a.capture
proof = json.loads((root / 'current-bond-independent-rf-proof.json').read_text())
meta = json.loads((root / 'rf-transport-metadata.json').read_text())
assert meta['sourceSha256'] == proof['sourcePacketsSha256']
epoch = next(x for x in proof['epochs'] if x['fullImageRfCoverageQualified'])
aa = epoch['aa']
chunks = [x for x in meta['canonicalImageChunks'] if x['aa'] == aa]
image_bytes=proof.get('imageBytes',1731024);expected_chunks=proof.get('expectedCanonicalImageChunks',3908)
assert len(chunks)==expected_chunks and sum(x['bytes'] for x in chunks)==image_bytes
start, last_start = min(x['firstUs'] for x in chunks), max(x['lastUs'] for x in chunks)
verified = {x['us']: x for x in meta['micVerifiedPackets'] if x['aa'] == aa}
frames, seed = [], None
source = root / 'packets-private.jsonl'
assert hashlib.sha256(source.read_bytes()).hexdigest() == proof['sourcePacketsSha256']
for line in source.read_text().splitlines():
    x = json.loads(line)
    raw = bytes.fromhex(x['pdu'])
    if x['aa'] == '8e89bed6' and len(raw) == 36 and raw[0] & 15 == 5:
        if f'{int.from_bytes(raw[14:18], "little"):08x}' == aa and wire_crc(raw, 0x555555) == x['crc']:
            seed = int.from_bytes(raw[18:21], 'big')
    if x['aa'] != aa or not start <= x['deviceTimestampUs'] <= last_start:
        continue
    assert seed is not None
    if len(raw) != 2 + raw[1] or not x['crcValid'] or wire_crc(raw, seed) != x['crc']:
        continue
    m = verified.get(x['deviceTimestampUs'])
    if not raw[1]:
        category = 'empty_ack_or_poll'
    elif m and m['llid'] == 3:
        category = 'control'
    elif m:
        category = ('central' if m['direction'] == 1 else 'peripheral') + '_data_' + ('repeat' if m['duplicateCounter'] else 'unique')
    else:
        category = 'nonempty_not_authenticated'
    x.update(raw=raw, mic=m, category=category, airUs=(11 + raw[1]) * 4)
    x['endUs'] = x['deviceTimestampUs'] + x['airUs']
    frames.append(x)
assert frames and frames[-1]['deviceTimestampUs'] == last_start
end = frames[-1]['endUs']
span = end - start
counts = collections.Counter(x['category'] for x in frames)
air = collections.Counter()
for x in frames:
    air[x['category']] += x['airUs']
gaps = [y['deviceTimestampUs'] - x['endUs'] for x, y in zip(frames, frames[1:])]
# The independently mandatory150us is not assigned to any operating system.
# Where IRQ timing makes the observed gap shorter, account only its positive
# part instead of silently making the time partition exceed the measured ROI.
accounted_ifs = sum(min(150, max(0, g)) for g in gaps)
overlap = sum(-g for g in gaps if g < 0)
central = [x for x in frames if x['mic'] and x['mic']['direction'] == 1 and x['mic']['llid'] in (1, 2)]
prior, repeat_edges, repeat_examples = {}, 0, []
for x in central:
    m = x['mic']
    key = m['session'], m['counter'], m['sn']
    old = prior.get(key)
    if old and old['channel'] != x['channel'] and x['deviceTimestampUs'] - old['deviceTimestampUs'] > 500:
        assert old['raw'][2:] == x['raw'][2:]
        repeat_edges += 1
        if len(repeat_examples) < 5:
            repeat_examples.append(dict(counter=m['counter'], fromUs=old['deviceTimestampUs'],
                toUs=x['deviceTimestampUs'], fromChannel=old['channel'], toChannel=x['channel']))
    prior[key] = x
groups = []
for x in central:
    if not groups or x['channel'] != groups[-1][-1]['channel']:
        groups.append([])
    groups[-1].append(x)
short = [g for g in groups if g[-1]['endUs'] - g[0]['deviceTimestampUs'] < 7000]
spans = [g[-1]['endUs'] - g[0]['deviceTimestampUs'] for g in short]
group_gaps = [y[0]['deviceTimestampUs'] - x[-1]['endUs'] for x, y in zip(groups, groups[1:])
              if x[-1]['endUs'] - x[0]['deviceTimestampUs'] < 7000]
out = dict(at=datetime.datetime.now().astimezone().isoformat(), capture=str(root.resolve()),
    sourceSha256=proof['sourcePacketsSha256'], accessAddress=aa, timestampBasis=json.loads((root/'capture.json').read_text()).get('timestampBasis','legacy'),
    fullRfImageBytes=image_bytes, fullRfImageChunks=expected_chunks, imageProfile=proof.get('imageProfile','original22'),
    imageSpanFirstStartToLastEndUs=span, usefulDecimalKBps=image_bytes*1000/span,
    packetCounts=dict(counts), observedPacketAirtimeUs=dict(air),
    allObservedPacketAirtimeUs=sum(air.values()),
    conservativelyAccountedMandatoryAdjacencyIfsUs=accounted_ifs,
    observedOverlapDueToTimestampUncertaintyUs=overlap,
    unassignedRemainderUs=span-sum(air.values())-accounted_ifs,
    crossChannelIdenticalCounterSnCiphertextRepeatEdges=repeat_edges,
    repeatExamples=repeat_examples,
    groupsWithCentralData=len(groups), shortGroups=len(short),
    shortGroupLastMd1=sum(bool(g[-1]['mic']['md']) for g in short),
    medianShortCentralGroupSpanUs=statistics.median(spans) if spans else None,
    medianGapToNextChannelUs=statistics.median(group_gaps) if group_gaps else None,
    centralPayloadHistogram=dict(collections.Counter(x['mic']['bytes'] for x in central)),
    scope=['ROI must be independently byte-complete and authenticated2M. Empty ACK/poll coverage can still be incomplete.',
      'Radio time formula includes2B preamble,AA,header,CRC. Timestamp basis is recorded from the receiver; legacy IRQ-derived runs have additional uncertainty.',
      'Mandatory IFS is a conservative accounted minimum. Residual includes scheduling, unobserved packets and timing uncertainty; no unique Windows/ESP attribution.',
      'Identical counter/SN/ciphertext on distinct channels proves actual repeat observations, not which receiver missed the previous ACK.',
      'Channel groups are an approximation, not universally exact connection-event boundaries.'])
a.output.write_text(json.dumps(out, indent=2))
print(json.dumps({k: out[k] for k in ('usefulDecimalKBps','packetCounts','allObservedPacketAirtimeUs','conservativelyAccountedMandatoryAdjacencyIfsUs','unassignedRemainderUs','crossChannelIdenticalCounterSnCiphertextRepeatEdges','medianShortCentralGroupSpanUs','medianGapToNextChannelUs')}))
