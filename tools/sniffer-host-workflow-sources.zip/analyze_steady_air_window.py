"""Recompute a steady window from an independently byte-complete RF run.

No new device operations. Empty ACK coverage can be incomplete. Same-channel
central groups are approximate events, not a controller scheduling trace.
"""
import argparse
import collections
import datetime
import hashlib
import json
import statistics
from pathlib import Path
from fresh_rf_gate import wire_crc

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--capture', type=Path, required=True)
p.add_argument('--start-second', type=int, default=22)
p.add_argument('--end-second', type=int, default=57)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
assert 0 <= a.start_second < a.end_second
proof = json.loads((a.capture/'current-bond-independent-rf-proof.json').read_text())
meta = json.loads((a.capture/'rf-transport-metadata.json').read_text())
assert meta['sourceSha256'] == proof['sourcePacketsSha256']
epoch = next(x for x in proof['epochs'] if x['fullImageRfCoverageQualified'])
aa = epoch['aa']
chunks = [x for x in meta['canonicalImageChunks'] if x['aa'] == aa]
assert sum(x['bytes'] for x in chunks) == proof['imageBytes']
assert len(chunks) == proof['expectedCanonicalImageChunks']
origin = min(x['firstUs'] for x in chunks)
lo = origin + a.start_second*1_000_000
hi = origin + a.end_second*1_000_000
assert hi <= max(x['lastUs'] for x in chunks)
verified = {x['us']: x for x in meta['micVerifiedPackets'] if x['aa'] == aa}
source = a.capture/'packets-private.jsonl'
assert hashlib.sha256(source.read_bytes()).hexdigest() == proof['sourcePacketsSha256']
frames, seed = [], None
for line in source.read_text().splitlines():
    x = json.loads(line)
    raw = bytes.fromhex(x['pdu'])
    if x['aa'] == '8e89bed6' and len(raw) == 36 and raw[0]&15 == 5:
        if f'{int.from_bytes(raw[14:18], "little"):08x}' == aa and wire_crc(raw, 0x555555) == x['crc']:
            seed = int.from_bytes(raw[18:21], 'big')
    if x['aa'] != aa or not lo <= x['deviceTimestampUs'] < hi:
        continue
    assert seed is not None
    if len(raw) != 2+raw[1] or not x['crcValid'] or wire_crc(raw, seed) != x['crc']:
        continue
    m = verified.get(x['deviceTimestampUs'])
    if not raw[1]:
        category = 'empty_ack_or_poll'
    elif m and m['llid'] == 3:
        category = 'control'
    elif m:
        category = ('central' if m['direction'] == 1 else 'peripheral') + ('_repeat' if m['duplicateCounter'] else '_unique')
    else:
        category = 'nonempty_not_authenticated'
    air = (11+raw[1])*4
    frames.append(dict(us=x['deviceTimestampUs'], end=x['deviceTimestampUs']+air,
        air=air, category=category, m=m, channel=x['channel'], payload=raw[1]))
assert frames
duration = a.end_second-a.start_second
fresh = sum(x['bytes'] for x in chunks if lo <= x['lastUs'] < hi)
air = collections.Counter()
counts = collections.Counter()
for x in frames:
    air[x['category']] += x['air']
    counts[x['category']] += 1
# Historical budget convention: max150us of each observed adjacent gap.
# Not an exact allocation of mandatory IFS: inter-event gaps are included.
adjacency = sum(min(150, max(0, y['us']-x['end'])) for x,y in zip(frames, frames[1:]))
central = [x for x in frames if x['m'] and x['m']['direction']==1 and x['m']['llid'] in (1,2)]
groups = []
for x in central:
    if not groups or groups[-1][-1]['channel'] != x['channel']:
        groups.append([])
    groups[-1].append(x)
short = [g for g in groups if g[-1]['end']-g[0]['us'] < 7000]
gaps = [y[0]['us']-x[-1]['end'] for x,y in zip(groups,groups[1:]) if x[-1]['end']-x[0]['us'] < 7000]
out = dict(at=datetime.datetime.now().astimezone().isoformat(), sourcePacketsSha256=proof['sourcePacketsSha256'],
    fullCaptureProven=True, startSecond=a.start_second, endSecondExclusive=a.end_second,
    windowSeconds=duration, freshImageBytes=fresh, steadyKBps=fresh/duration/1000,
    neededFor167p5KBpsBytesPer7p5ms=167500*.0075,
    actualFreshBytesPer7p5ms=fresh/duration*.0075,
    additionalFreshBytesPer7p5ms=167500*.0075-fresh/duration*.0075,
    measuredPacketAirSeconds={k:v/1e6 for k,v in air.items()}, packetCounts=dict(counts),
    cappedObservedAdjacencyGapSeconds=adjacency/1e6,
    unassignedSeconds=duration-sum(air.values())/1e6-adjacency/1e6,
    medianCentralGroupUs=statistics.median(g[-1]['end']-g[0]['us'] for g in short),
    medianNextGroupGapUs=statistics.median(gaps),
    uniqueCentralPayloadHistogram=dict(collections.Counter(x['payload'] for x in central if x['category']=='central_unique')),
    scope=['Saved independently byte-complete current-peer image. No new OTA or device actions.',
        'Fresh completed-chunk attribution can shift by at most443B at each window edge.',
        'Capped observed adjacency gaps are a budget convention, not exact mandatory IFS.',
        'Unassigned time includes unobserved packets and scheduling; it is not all idle or reclaimable.',
        'Channel groups approximate events. No exclusive Windows/ESP attribution or official packet trace.'])
a.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:out[k] for k in ['steadyKBps','actualFreshBytesPer7p5ms','additionalFreshBytesPer7p5ms','medianCentralGroupUs','medianNextGroupGapUs','unassignedSeconds']}))
