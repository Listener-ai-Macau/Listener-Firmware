from pathlib import Path
import datetime, json, os, subprocess, time, psutil
R=Path(__file__).resolve().parent
src=R/'source-rxdiag128'
sdk=Path(json.loads((R/'sdk-location.json').read_text())['sdkPath'])
tools=R/'build-tools/xpack-windows-build-tools-4.4.1-3/bin'
env=os.environ.copy();env['PATH']=str(tools)+os.pathsep+env['PATH']
meta=dict(startedAt=datetime.datetime.now().astimezone().isoformat(),jobs=1,source=str(src),
    hardwareInstalled=False,scope='Analyzer receive counters only; no product changes or upload')
cmd=[str(tools/'make.exe'),'-j1','nrf52840_xxaa','SDK_ROOT='+sdk.as_posix(),
    'GNU_INSTALL_ROOT=C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin/',
    'GNU_VERSION=14.2.1','GNU_PREFIX=arm-none-eabi','VERBOSE=1']
name='cross-build128-'+str(time.time_ns())+'.log'
with (R/name).open('wb') as log:
    proc=subprocess.Popen(cmd,cwd=src,env=env,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
    psutil.Process(proc.pid).nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    meta['pid']=proc.pid;(R/'cross-build128.json').write_text(json.dumps(meta,indent=2))
    meta['exit']=proc.wait()
meta.update(log=name,completedAt=datetime.datetime.now().astimezone().isoformat())
(R/'cross-build128.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta))
raise SystemExit(meta['exit'])
