"""Local receiver owner: captures share one COM handle; no RF/Type/product commands beyond passive capture."""
from pathlib import Path
import argparse,csv,datetime,hashlib,io,json,os,re,subprocess,time,threading,uuid
from multiprocessing.connection import Listener,Client
import psutil,serial
from serial.tools import list_ports
from butterfly_passive_capture import capture,command,wire,Frames
ROOT=Path(__file__).resolve().parent
SOURCE_HASHES={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ('receiver_session.py','butterfly_passive_capture.py')}
STATE=ROOT/'receiver-session-private'
PIPE=r'\\.\pipe\ListenerPassiveReceiver-C06430228A01'
def now():return datetime.datetime.now().astimezone().isoformat()
def admit_output(value):
 path=Path(value).resolve()
 if not path.is_relative_to(ROOT) or path.exists():raise ValueError('New output directory under analyzer workspace required')
 return path
def info(port):
 codec=Frames();result={};q=command('discovery','info_query');q.discovery.info_query.proto_ver=0x100
 port.write(wire(q));deadline=time.monotonic()+3
 while time.monotonic()<deadline:
  for msg in codec.feed(port.read(port.in_waiting or 1)):
   domain=msg.WhichOneof('msg');kind=getattr(msg,domain).WhichOneof('msg') if domain else None
   if (domain,kind)==('generic','debug'):
    text=bytes(msg.generic.debug.data).decode('ascii',errors='replace')
    if text.startswith('heap '):result['heap']=dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',text))
    if text.startswith('receiver_boot '):result['boot']=dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',text))
   if (domain,kind)==('discovery','info_resp'):
    v=msg.discovery.info_resp;result['firmware']=f'{v.fw_version_major}.{v.fw_version_minor}.{v.fw_version_rev}'
  if 'firmware' in result and 'boot' in result:return result
 raise TimeoutError('Receiver info not acknowledged; keep fault state for inspection')
def request(payload):
 key=(STATE/'auth.bin').read_bytes()
 with Client(PIPE,family='AF_PIPE',authkey=key) as conn:
  conn.send(payload);return conn.recv()
def serve():
 STATE.mkdir(exist_ok=True)
 old=STATE/'owner.json'
 if old.exists():
  previous=json.loads(old.read_text())
  if previous.get('running') and psutil.pid_exists(previous['pid']):raise RuntimeError('Existing receiver owner must be reused')
 sid=list(csv.reader(io.StringIO(subprocess.check_output(['whoami','/user','/fo','csv','/nh'],text=True))))[0][1]
 subprocess.run(['icacls',str(STATE),'/inheritance:r','/grant:r','*'+sid+':(OI)(CI)F','SYSTEM:(OI)(CI)F'],stdout=subprocess.DEVNULL,check=True)
 key=os.urandom(32);(STATE/'auth.bin').write_bytes(key)
 owner=dict(pid=os.getpid(),startedAt=now(),running=True,protocolVersion=7,sourceSha256=SOURCE_HASHES,port=None,portOpenCount=0,captures=0,productCommands=0,firmwareWrites=0,focusOperations=0)
 lock=threading.RLock();jobs={};active=None
 def save():
  with lock:
   tmp=old.with_suffix('.tmp');tmp.write_text(json.dumps(owner,indent=2));os.replace(tmp,old)
 port=None;save()
 try:
  deadline=time.monotonic()+8
  while time.monotonic()<deadline:
   candidates=[p for p in list_ports.comports() if (p.vid,p.pid,p.serial_number)==(0xc0ff,0xeeee,'C06430228A01')]
   if len(candidates)==1:
    try:port=serial.Serial(candidates[0].device,115200,timeout=.05,write_timeout=2)
    except serial.SerialException as error:
     if isinstance(error.__context__,FileNotFoundError) or 'FileNotFoundError(2' in str(error):
      owner['lastEnumerationRace']='Exact receiver node disappeared before open; waiting within the same8-second enumeration budget';save();time.sleep(.1);continue
     raise
    owner.update(port=candidates[0].device,portOpenCount=1);break
   time.sleep(.1)
  if port is None:raise RuntimeError('Exact receiver identity not available; no reset or product command issued')
  owner['initialInfo']=info(port);save()
  def launch(payload):
   nonlocal active
   seconds=int(payload.get('seconds',5));channel=int(payload.get('channel',38))
   if not 1<=seconds<=600 or channel not in (37,38,39):raise ValueError('Capture must be bounded to1..600seconds')
   target=admit_output(payload['output'])
   with lock:
    if active is not None:raise RuntimeError('Another passive capture owns the receiver; do not interleave serial commands')
    job=dict(id=uuid.uuid4().hex,output=str(target),cancel=threading.Event(),done=threading.Event(),result=None)
    active=job;jobs[job['id']]=job
    owner.update(captureActive=True,activeJob=job['id']);save()
   def work():
    nonlocal active
    try:
     result=capture(owner['port'],target,seconds,channel,bool(payload.get('passiveKey',False)),bool(payload.get('radioCheck',False)),bool(payload.get('fixedAdvertising',False)),borrowed_port=port,target_address=payload.get('targetAddress'),tracking_only=bool(payload.get('trackingOnly',False)),stop_event=job['cancel'])
     job['result']={'ok':True,'capture':result}
    except Exception as error:
     job['result']={'ok':False,'error':type(error).__name__+': '+str(error)}
    finally:
     with lock:
      owner['captures']+=1;owner['lastCapture']=str(target);owner['lastJob']=job['id']
      owner['captureActive']=False;owner.pop('activeJob',None)
      if not job['result']['ok']:owner['lastError']=job['result']['error']
      active=None;save();job['done'].set()
   threading.Thread(target=work,daemon=False).start()
   return job
  def reply_when_finished(conn,job):
   try:
    job['done'].wait()
    with lock:conn.send(dict(job['result'],owner=dict(owner)))
   finally:conn.close()
  with Listener(PIPE,family='AF_PIPE',authkey=key) as server:
   while True:
    conn=server.accept();deferred=False
    try:
     payload=conn.recv();action=payload.get('action');response={}
     try:
      if action=='status':
       with lock:response={'ok':True,'owner':dict(owner)}
      elif action=='info':
       with lock:
        if active is not None:raise RuntimeError('Serial info command refused during active reception; use status')
        response={'ok':True,'receiver':info(port),'owner':dict(owner)}
      elif action=='reloadCapture':
       with lock:
        if active is not None:raise RuntimeError('Capture-module reload refused while receiving')
        # Fixed local module only; no caller-provided path or code. Reloading
        # a corrected host decoder/configuration must not close/reset the USB.
        module_path=ROOT/'butterfly_passive_capture.py';source=module_path.read_bytes()
        digest=hashlib.sha256(source).hexdigest()
        if digest!=payload.get('expectedSha256'):raise ValueError('Capture module SHA does not match reviewed source')
        import types
        module=types.ModuleType('listener_passive_capture_reloaded');module.__file__=str(module_path)
        exec(compile(source,str(module_path),'exec'),module.__dict__)
        global capture
        capture=module.capture
        owner['sourceSha256']['butterfly_passive_capture.py']=digest
        owner['captureModuleReloads']=owner.get('captureModuleReloads',0)+1
        save();response={'ok':True,'captureModuleSha256':digest,'portKeptOpen':True,'owner':dict(owner)}
      elif action in ('capture','captureStart'):
       job=launch(payload)
       if action=='capture':
        threading.Thread(target=reply_when_finished,args=(conn,job),daemon=False).start();deferred=True
       else:response={'ok':True,'job':job['id'],'output':job['output'],'started':True}
      elif action in ('captureStatus','captureStop'):
       with lock:
        job=jobs.get(payload.get('job'))
        if job is None:raise ValueError('Exact known capture job required')
        if action=='captureStop' and not job['done'].is_set():job['cancel'].set()
        response={'ok':True,'job':job['id'],'done':job['done'].is_set(),'cancelRequested':job['cancel'].is_set(),'result':job['result']}
      elif action=='stop':
       with lock:
        if active is not None:raise RuntimeError('Cancel the capture and await stop acknowledgement before closing the receiver')
       conn.send({'ok':True,'closingReceiverPortOnce':True,'scope':'Receiver only; firmware PORT_CLOSE intentionally resets application'})
       break
      else:raise ValueError('Only passive receiver lifecycle/status/capture commands are supported')
     except Exception as e:
      response={'ok':False,'error':type(e).__name__+': '+str(e)}
     if not deferred:conn.send(response)
    finally:
     if not deferred:conn.close()
 finally:
  if port:port.close()
  owner.update(running=False,endedAt=now());save()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['serve','status','info','capture','captureStart','captureStatus','captureStop','stop']);p.add_argument('--output');p.add_argument('--job');p.add_argument('--seconds',type=int,default=5);p.add_argument('--channel',type=int,choices=[37,38,39],default=38);p.add_argument('--passive-key',action='store_true');p.add_argument('--radio-check',action='store_true');p.add_argument('--fixed-advertising',action='store_true');p.add_argument('--target-address');p.add_argument('--tracking-only',action='store_true');a=p.parse_args()
 if a.action=='serve':serve()
 else:
  value={'action':a.action}
  if a.action in ('captureStatus','captureStop'):value['job']=a.job
  if a.action in ('capture','captureStart'):
   assert a.output
   value.update(output=str(Path(a.output).resolve()),seconds=a.seconds,channel=a.channel,passiveKey=a.passive_key,radioCheck=a.radio_check,fixedAdvertising=a.fixed_advertising,targetAddress=a.target_address,trackingOnly=a.tracking_only)
  result=request(value);print(json.dumps(result,indent=2))
  if not result.get('ok'):raise SystemExit(1)
