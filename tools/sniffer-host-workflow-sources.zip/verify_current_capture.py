"""Independent current-peer RF MIC, L2CAP reassembly and exact OTA image coverage.

Plaintext remains in memory. Only protocol/timing/count metadata is emitted.
Every missing frame/offset remains a gap; no inferred bytes or zero-loss claim.
"""
from pathlib import Path
import argparse,collections,datetime,hashlib,json,time
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes
from cryptography.hazmat.primitives.ciphers.aead import AESCCM
from fresh_rf_gate import wire_crc
p=argparse.ArgumentParser();p.add_argument('--capture',type=Path,required=True);p.add_argument('--image-profile',choices=('original22','long34'),default='original22');a=p.parse_args()
r=Path(__file__).parent;capture=a.capture.resolve();w=r.parents[1]
from peer_binding import for_capture
reference,proof=for_capture(capture/'packets-private.jsonl')
key=bytes.fromhex(reference['keyBigEndian'][2:]);lookups=set(proof['lookupFingerprints'])
source=capture/'packets-private.jsonl';groups=collections.defaultdict(list)
seeds={};crc_counts=collections.defaultdict(collections.Counter)
for line in source.read_text().splitlines():
    row=json.loads(line)
    raw=bytes.fromhex(row['pdu'])
    if len(raw)<2 or len(raw)!=2+raw[1] or not row['crcValid']:continue
    if row['aa']=='8e89bed6':
        if len(raw)==36 and raw[0]&15==5 and wire_crc(raw,0x555555)==row['crc']:
            aa=f'{int.from_bytes(raw[14:18],"little"):08x}'
            seeds[aa]=int.from_bytes(raw[18:21],'big')
        continue
    seed=seeds.get(row['aa'])
    if seed is None:crc_counts[row['aa']]['unknown']+=1
    elif wire_crc(raw,seed)!=row['crc']:
        crc_counts[row['aa']]['rejected']+=1
        continue
    else:crc_counts[row['aa']]['validated']+=1
    groups[row['aa']].append(row)
image=(w/'outputs/firmware-audio-block22-20261017/listener-ota-1.0.6-rc1-20261017-181137/firmware_ota.bin').read_bytes()
if a.image_profile=='long34':
    prepared=json.loads((r/'prepared-long-air-load34.json').read_text());assert prepared['buildExit']==0 and prepared['validEspImage'] and prepared['readOnlyFlashBlobVerified']
    image=(Path(prepared['package'])/'firmware_ota.bin').read_bytes();assert hashlib.sha256(image).hexdigest()==prepared['imageSha256'] and len(image)==prepared['imageBytes']
capture_meta=json.loads((capture/'capture.json').read_text())
export_stats=capture_meta.get('rfExportStats',{})
export_loss=sum(export_stats.get(k,0) for k in ('drops','invalid','errors'))
epochs=[];started=time.monotonic(); packet_metadata=[]; chunk_metadata=[]
for aa,frames in groups.items():
    request=None;ccm=None;iv=None;counters=[0,0];seen=set();verified=duplicates=failed=0;session_index=0
    controls=[];chunks={};l2cap={};partial=0;orphans=0;invalid_image=0;max_payload=0;first_us=last_us=None;bounded=False
    for row in frames:
        if time.monotonic()-started>25:bounded=True;break
        raw=bytes.fromhex(row['pdu']);payload=raw[2:];llid=raw[0]&3
        if len(raw)!=2+raw[1]:continue
        if llid==3 and len(payload)==23 and payload[0]==3:
            if hashlib.sha256(payload[1:11]).hexdigest() in lookups:
                request=payload;ccm=None;iv=None
            continue
        if llid==3 and len(payload)==13 and payload[0]==4 and request is not None and ccm is None:
            aes=Cipher(algorithms.AES(key),modes.ECB()).encryptor();session=aes.update((request[11:19]+payload[1:9])[::-1])+aes.finalize()
            ccm=AESCCM(session,tag_length=4);iv=request[19:23]+payload[9:13]
            counters=[0,0];session_index+=1;request=None
            # Rekeying resets nonce counters on the same access address. A new
            # handshake alone grants no plaintext: every packet still needs MIC.
            partial+=len(l2cap);l2cap.clear()
            continue
        if ccm is None or len(payload)<5:continue
        hint=1 if row['direction']==1 else 0 if row['direction']==2 else None
        match=None
        for direction in ([hint,1-hint] if hint is not None else [0,1]):
            start=counters[direction]
            candidates=list(dict.fromkeys([start,max(0,start-1)]+list(range(start+1,start+129))))
            for counter in candidates:
                nonce=bytearray(counter.to_bytes(5,'little')+iv);nonce[4]=(nonce[4]&127)|(direction<<7)
                try:plain=ccm.decrypt(bytes(nonce),payload,bytes([raw[0]&0xe3]))
                except InvalidTag:continue
                match=(direction,counter,plain);break
            if match:break
        if match is None:failed+=1;continue
        direction,counter,plain=match;verified+=1;max_payload=max(max_payload,len(payload))
        packet_metadata.append({'aa':aa,'us':row['deviceTimestampUs'],'hostEpoch':row['hostArrivalEpoch'],'session':session_index,'direction':direction,'counter':counter,'llid':llid,'bytes':len(payload),'sn':(raw[0]>>3)&1,'nesn':(raw[0]>>2)&1,'md':bool(raw[0]&16),'channel':row['channel'],'duplicateCounter':(session_index,direction,counter) in seen})
        first_us=first_us if first_us is not None else row['deviceTimestampUs'];last_us=row['deviceTimestampUs']
        counters[direction]=max(counters[direction],counter+1)
        if (session_index,direction,counter) in seen:duplicates+=1;continue
        seen.add((session_index,direction,counter))
        if llid==3 and plain:
            control={'deviceUs':row['deviceTimestampUs'],'sessionIndex':session_index,'direction':direction,'counter':counter,'opcode':hex(plain[0])}
            if plain[0]==0x18 and len(plain)==5:control.update(c2p=plain[1],p2c=plain[2],instant=int.from_bytes(plain[3:5],'little'))
            if plain[0]==0 and len(plain)==12:control.update(windowSizeUnits=plain[1],windowOffsetUnits=int.from_bytes(plain[2:4],'little'),intervalUnits=int.from_bytes(plain[4:6],'little'),latencyUnits=int.from_bytes(plain[6:8],'little'),supervisionTimeoutUnits=int.from_bytes(plain[8:10],'little'),instant=int.from_bytes(plain[10:12],'little'))
            if plain[0] in (0x16,0x17) and len(plain)==3:control.update(txPhys=plain[1],rxPhys=plain[2])
            if plain[0] in (0x14,0x15) and len(plain)==9:control.update(maxRxOctets=int.from_bytes(plain[1:3],'little'),maxRxTime=int.from_bytes(plain[3:5],'little'),maxTxOctets=int.from_bytes(plain[5:7],'little'),maxTxTime=int.from_bytes(plain[7:9],'little'))
            if plain[0]==2 and len(plain)==2:control['errorCode']=plain[1]
            if plain[0]==1 and len(plain)==8:control.update(channelMap=plain[1:6].hex(),instant=int.from_bytes(plain[6:8],'little'))
            controls.append(control);continue
        if llid==2:
            if direction in l2cap:partial+=1
            l2cap[direction]={'bytes':bytearray(plain),'firstUs':row['deviceTimestampUs']}
        elif llid==1 and plain:
            if direction not in l2cap:orphans+=1;continue
            l2cap[direction]['bytes'].extend(plain)
        else:continue
        state=l2cap.get(direction)
        if not state or len(state['bytes'])<4:continue
        data=state['bytes'];expected=int.from_bytes(data[:2],'little')+4
        if len(data)<expected:continue
        del l2cap[direction]
        if len(data)!=expected:partial+=1;continue
        if int.from_bytes(data[2:4],'little')!=4:continue
        att=bytes(data[4:])
        if len(att)<7 or att[0]!=0x52 or int.from_bytes(att[1:3],'little') not in (0x13,0x15):continue
        offset=int.from_bytes(att[3:7],'little');body=att[7:]
        if not body or offset+len(body)>len(image) or body!=image[offset:offset+len(body)]:invalid_image+=1;continue
        chunks[offset]={'bytes':len(body),'firstUs':state['firstUs'],'lastUs':row['deviceTimestampUs']}
        chunk_metadata.append({'aa':aa,'offset':offset,**chunks[offset]})
    cursor=0;gaps=[]
    for offset,c in sorted(chunks.items()):
        if offset>cursor:gaps.append({'start':cursor,'end':offset})
        cursor=max(cursor,offset+c['bytes'])
    if cursor<len(image):gaps.append({'start':cursor,'end':len(image)})
    complete=bool(chunks) and export_loss==0 and not gaps and invalid_image==0 and not bounded and not crc_counts[aa]['unknown']
    first_chunk=min((x['firstUs'] for x in chunks.values()),default=None)
    last_chunk=max((x['lastUs'] for x in chunks.values()),default=None)
    span=last_chunk-first_chunk if chunks else 0
    epochs.append({'aa':aa,'crcValidPdus':len(frames),'independentRawCrc':dict(crc_counts[aa]),'handshakeComplete':ccm is not None,
      'sessionHandshakes':session_index,'micVerified':verified,'duplicateCounterObservations':duplicates,'unverifiedEncryptedCandidates':failed,
      'maxVerifiedPayloadBytes':max_payload,'authenticatedSpanUs':last_us-first_us if last_us is not None else 0,
      'lastCounters':counters,'authenticatedControls':controls,'imageChunks':len(chunks),
      'imageBytesCovered':sum(x['bytes'] for x in chunks.values()),'imageGapRanges':gaps,
      'invalidImageSdus':invalid_image,'incompleteL2cap':partial+len(l2cap),'orphanContinuations':orphans,
      'fullImageRfCoverageQualified':complete,'boundedAnalysisStopped':bounded,
      'observedImageTimestampSpanUs':span,
      'observedImagePayloadKBps':len(image)*1000/span if complete and span else None,
      'scope':'Complete image criterion requires every original image byte in actual MIC-verified reassembled RF. Packet timestamp span omits final ACK boundary; duplicate observations are not a full retransmission rate.'})
result={'at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
 'currentPeer':proof['currentPeer'],'privateReferenceSha256':proof['privateReferenceSha256'],
 'sourcePacketsSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'imageSha256':hashlib.sha256(image).hexdigest(),
 'imageProfile':a.image_profile,'imageBytes':len(image),'expectedCanonicalImageChunks':(len(image)+442)//443,'rfExportStats':export_stats,'rfExportLossCount':export_loss,'epochs':epochs,'keyOrPlaintextExported':False,'pureAirExclusiveOccupancyProven':False}
(capture/'rf-transport-metadata.json').write_text(json.dumps({'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'micVerifiedPackets':packet_metadata,'canonicalImageChunks':chunk_metadata,'keyOrPlaintextExported':False},separators=(',',':')))
(capture/'current-bond-independent-rf-proof.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'at':result['at'],'connections':len(epochs),'micVerified':sum(x['micVerified'] for x in epochs),
 'maxVerifiedPayloadBytes':max([x['maxVerifiedPayloadBytes'] for x in epochs],default=0),
 'imageChunks':sum(x['imageChunks'] for x in epochs),'completeImageConnections':sum(x['fullImageRfCoverageQualified'] for x in epochs)}))
