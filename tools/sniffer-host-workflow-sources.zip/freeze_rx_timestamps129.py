"""Freeze application-only receive counters plus RF export-clock correction."""
from pathlib import Path
import datetime,hashlib,json,struct,subprocess,zipfile
R=Path(__file__).resolve().parent;src=R/'source-rxtiming129';image=R/'butterfly-passive-1.1.129.zip'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prepared=json.loads((R/'prepared-rxtiming129-source.json').read_text());build=json.loads((R/'cross-build129.json').read_text())
proof=json.loads((R/'rx-export-timestamp129-arm-before-after.json').read_text())
assert build['exit']==0 and prepared['baseCommit']=='75c382000308d7d78f5c9302ea274b1553981552'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()==prepared['candidateCommit']
assert not subprocess.check_output(['git','diff','HEAD','--'],cwd=src)
assert set(subprocess.check_output(['git','diff',prepared['baseCommit'],'--name-only'],cwd=src,text=True).splitlines())==set(prepared['changedFiles'])
assert (src/'src/passive_crypto.c').read_text()==(R/'source/src/passive_crypto.c').read_text()
assert (src/'src/receiver_export.c').read_text()==(R/'source/src/receiver_export.c').read_text()
assert proof['afterElfSha256']==sha(src/'build/nrf52840_xxaa.out') and proof['caseCount']==11 and len(proof['full1mReceivePathCases'])==3
assert proof['packetControllerAndExportLayoutSizesUnchanged']
with zipfile.ZipFile(image) as z:
 assert z.testzip() is None
 m=json.loads(z.read('manifest.json'))['manifest'];assert set(m)=={'application'}
 app=m['application'];assert set(z.namelist())=={'manifest.json',app['bin_file'],app['dat_file']}
 payload=z.read(app['bin_file']);assert payload==(src/'build/nrf52840_xxaa.bin').read_bytes()
 stack,reset=struct.unpack_from('<II',payload);assert 0x20000000<stack<=0x20040000 and reset&1
 assert 0x1000<=(reset&~1)<0x1000+len(payload)<0xe0000
upper=0;addresses=[]
for line in (src/'build/nrf52840_xxaa.hex').read_text().splitlines():
 v=bytes.fromhex(line[1:]);assert not sum(v)&255
 if v[3]==4:upper=int.from_bytes(v[4:6],'big')<<16
 elif v[3]==2:upper=int.from_bytes(v[4:6],'big')<<4
 elif v[3]==0:addresses.extend(range(upper+int.from_bytes(v[1:3],'big'),upper+int.from_bytes(v[1:3],'big')+v[0]))
assert min(addresses)==0x1000 and max(addresses)<0xe0000
old=json.loads((R/'prepared-custom-128.json').read_text())
assert sha(R/'restore-nordic-4.1.1.zip')==old['restoredNordicPackageSha256']
out=dict(at=datetime.datetime.now().astimezone().isoformat(),firmware='1.1.129',sourceCommit=prepared['candidateCommit'],
 baseCommit=prepared['baseCommit'],whadLibraryCommit='d856d1ddde7384d24bf3303ba22ce2201756712b',nanopbCommit='ae4959ec848503796f63319a7f3ae345b41f354a',
 package=image.name,packageSha256=sha(image),applicationBytes=len(payload),applicationSha256=hashlib.sha256(payload).hexdigest(),
 elfSha256=sha(src/'build/nrf52840_xxaa.out'),stackPointer=hex(stack),resetVector=hex(reset),loadStart=hex(min(addresses)),lastApplicationAddress=hex(max(addresses)),
 applicationOnly=True,bootloaderWritten=False,restoredNordicPackageSha256=old['restoredNordicPackageSha256'],
 actualArmProof='rx-export-timestamp129-arm-before-after.json',crossBuild=build,hardwareInstalled=False,
 supersedesUninstalled128=True,timestampBasis='PPI END minus complete BLE airtime; legacy controller and relative clocks unchanged',
 scope='Combines128 receive counters with raw-export clock correction. Actual ARM11 clock cases/3 full1M receive-export paths; MMIO and allocator fixtures disclosed. Global write observer artifact retained. No live RF calibration, current-peer capture, speed gain or product-firmware acceptance claimed.',
 primaryReferences=['https://docs.nordicsemi.com/r/bundle/ps_nrf52840/page/radio.html','https://www.bluetooth.com/wp-content/uploads/Files/Specification/HTML/Core-54/out/en/low-energy-controller/link-layer-specification.html'])
(R/'prepared-custom-129.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
